from delivery_check import evaluate_delivery
from llm_client import ask_model

result = evaluate_delivery(8, 1, True, 7)
print("Verified local result:", result)
instructions = (
    "Explain the supplied local result in two sentences. Do not change it "
    "or invent policy. Eligibility guidance does not approve a refund."
)
print(ask_model(instructions, f"Delivery eligibility result: {result}"))
