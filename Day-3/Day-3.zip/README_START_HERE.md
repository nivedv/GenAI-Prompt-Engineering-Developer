# Day 3 participant lab pack

Delivery: concept → trainer demo → participant lab → debrief. Start fresh; there is no Day 2 VS Code project. Scenario: Damaged Delivery Support. All contract data is synthetic.

## Setup in the VDI

1. Extract the ZIP into `C:\AgenticAI_Labs`. Open the extracted `Day3_Participant_Workflows` folder in VS Code. Avoid nesting another folder with the same name.
2. Open PowerShell and run:

```powershell
Set-Location C:\AgenticAI_Labs\Day3_Participant_Workflows
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
```

3. Edit `.env` locally with the trainer-provided resource inference URL, resource key and deployed model name. A ChatGPT login does not provide these Azure credentials. Keep the key out of screenshots and submitted context.
4. Select **Python: Select Interpreter** in VS Code and choose `.venv`. Activate with `.\.venv\Scripts\Activate.ps1`; if blocked, use `.\.venv\Scripts\python.exe` instead of `python` in every command.
5. Follow `labs/00_Delivery_Order.md`, then Labs 01–10 in order. Files that a lab asks you to create are supplied here: inspect their content instead of retyping them. Still perform all experiments and completion checks.

## Staged work and solutions

`delivery_check.py` is deliberately a stub. Complete Lab 03 before running its acceptance tests or the explainer. Model output is a proposal: review it before executing it.

Reference solutions are under `solutions/`. Read them after your first attempt. To recover at the relevant stage:

```powershell
# After attempting Lab 03 or Lab 04:
Copy-Item solutions\lab03\delivery_check.py delivery_check.py
python -m unittest test_delivery_acceptance -v
# After attempting Lab 05:
Copy-Item solutions\lab05\test_generated_delivery.py test_generated_delivery.py
python -m unittest test_generated_delivery -v
# Only at Lab 10, replace the weak runner:
Copy-Item solutions\lab10\developer_tasks.py developer_tasks.py
```

Keep the weak runner through Lab 09 so you can compare attack outcomes. Lab 10's `--hardened` option exists only after replacing or editing the runner.

## Verification and dependencies

Lab 01 verifies live Azure inference. Lab 03 verifies the local helper. Lab 05 verifies test sensitivity with a deliberate mutation. Labs 09–10 record actual attack outcomes, including attacks that do not succeed. Empty findings templates are supplied; no model outputs or live Azure results are fabricated.

The pack's Python syntax and reference acceptance checks were verified locally. Live model calls require your VDI's network access, Azure configuration and installed packages. Use the deployment and endpoint approved for the course. See `docs/SUPPORT_FILE_MAP.md` for the file-to-lab mapping.


## Trainer materials

The `trainer/` folder contains the concise slide deck with speaker notes and the trainer demo guide. Participant lab instructions are in `labs/`.
