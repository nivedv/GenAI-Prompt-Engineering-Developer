import os
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI

ROOT = Path(__file__).resolve().parent


def ask_model(instructions, content):
    load_dotenv(ROOT / ".env", override=True)
    client = OpenAI(
        base_url=os.environ["AZURE_OPENAI_BASE_URL"],
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        timeout=120.0,
        max_retries=0,
    )
    response = client.responses.create(
        model=os.environ["AZURE_OPENAI_DEPLOYMENT"],
        instructions=instructions,
        input=content,
    )
    if response.status != "completed" or not response.output_text.strip():
        raise RuntimeError(f"No completed answer. Status: {response.status}")
    return response.output_text
