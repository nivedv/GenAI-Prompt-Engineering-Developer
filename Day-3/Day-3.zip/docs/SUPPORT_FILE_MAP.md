# Supporting files by lab

| Lab | Ready files | Participant work |
| --- | --- | --- |
| 01 | Client, assistant, support prompt, contract, environment template | Configure credentials and perform live smoke test |
| 02 | 01_explain prompt | Compare incomplete and complete context |
| 03 | 02_generate prompt, stub, acceptance tests | Generate and verify helper |
| 04 | 03_review prompt, intentionally defective seed | Review and correct defects |
| 05 | 04_tests prompt, reference tests in solutions | Generate tests and detect mutation |
| 06 | 05_refactor prompt | Refactor while retaining passing checks |
| 07 | 06_document prompt, reference documentation | Write documentation from verified code |
| 08 | developer_tasks.py, delivery_explainer.py | Reuse prompts through Python |
| 09 | Clean seed and injected seed | Compare actual model responses |
| 10 | Variant injection, hardened runner in solutions | Add trust boundary and retest |

The seed files intentionally contain defects. The initial runner intentionally has a weak instruction boundary. The filename check for .env is a teaching safeguard, not a complete secret scanner. Hardening reduces risk; attack outcomes depend on the actual model and platform filters.
