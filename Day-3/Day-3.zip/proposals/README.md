Save raw model proposals here before editing runnable Python. Files in this folder are not automatically executed.
