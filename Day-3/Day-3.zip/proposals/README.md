Save model proposals here. Inspect them before copying reviewed code into executable files. This folder contains no pre-recorded model responses.
