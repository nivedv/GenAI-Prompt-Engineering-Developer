# Lab 02 — Code Explanation and Context

**Participant time:** 20 minutes  
**Scenario:** Damaged Delivery Support  
**Workspace:** `C:\AgenticAI_Labs\Day3_Participant_Workflows`  
**Before this lab:** Complete Lab 01. Use browser Foundry Playground or the extension with your deployed model.

## Concept and trainer demo

Code explanation should cite supplied source and mark omitted dependencies as unknown.

**Trainer demo:** Explain an entry point with and without its model-call helper.

## Your task

Compare explanations with incomplete and complete source context.

**Expected outcome:** A source-supported code map and one documented missing-context observation.

## Detailed instructions

1. Create `prompts/01_explain.txt` using this reusable task:

```text
Explain the supplied code for a new developer.
Describe input, processing, model call, output, errors and unknowns.
Support important claims with function names or short source excerpts.
Do not invent the behaviour of omitted functions. Do not modify code.
Keep the answer under 350 words.
```

2. Start a fresh Playground conversation. Submit the task plus the contents of `delivery_assistant.py` only. Save the response in `evidence/explain_incomplete.txt`.
3. Check what it claims about `ask_model`. Its internal authentication and model-call details are absent from this input.
4. Start another fresh conversation. Submit the same task plus both `delivery_assistant.py` and `llm_client.py`. Save `evidence/explain_complete.txt`.
5. Verify each claim against the actual files. Do not submit `.env`.
6. Compare which additional claims now have evidence.

## Completion check

Both responses are saved. The complete explanation maps argument parsing, prompt/policy loading, model invocation and response saving. Unsupported claims are identified rather than accepted.

## Record your observations

What changed when the helper was included? Which claim was a guess? What unrelated context did you exclude?

Use `evidence/lab_02_findings.md`. Record the prompt, context, exact response, local checks and one remaining limitation. Never record your API key.

## Solution — open after your first attempt

Reference explanation:

- `main` receives `--question` through argparse.
- The application reads instructions and contract from UTF-8 files.
- `ask_model` loads `.env`, creates an Azure-targeted OpenAI client and calls Responses using the deployment name.
- The client checks for a completed, non-empty answer.
- The application saves and prints the answer.
- The application does not execute model-generated code, approve payments or implement automatic conversation memory.

In the incomplete run, a valid answer identifies `ask_model` internals as unknown. If it describes the SDK or key loading without that helper being supplied, record an unsupported inference even if the guess happens to be correct.

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
