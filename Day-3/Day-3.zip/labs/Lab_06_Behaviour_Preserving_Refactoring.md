# Lab 06 — Behaviour Preserving Refactoring

**Participant time:** 15 minutes  
**Scenario:** Damaged Delivery Support  
**Workspace:** `C:\AgenticAI_Labs\Day3_Participant_Workflows`  
**Before this lab:** Complete Lab 05. Both test suites should pass.

## Concept and trainer demo

Refactoring changes code structure while preserving the public contract.

**Trainer demo:** Compare tests before and after a focused readability improvement.

## Your task

Assess and apply a justified refactor of the delivery checker.

**Expected outcome:** The interface, labels, rule order and test results remain unchanged.

## Detailed instructions

1. Save the current implementation and run both suites.
2. Save `prompts/05_refactor.txt`:

```text
Refactor the supplied function only if readability can improve.
Preserve the signature, rule order, labels and input scope.
Do not add dependencies or change policy. Return a replacement function
and a short change list. If already clear, return NO_CHANGE with a reason.
Do not claim you ran tests.
```

3. Submit the task, contract and current function. Save the proposal.
4. Inspect it. Accept only justified changes, or record NO_CHANGE.
5. Rerun both suites. Explain the comparison in your findings.

## Completion check

Both suites pass before and after. No public interface or policy rule changes. NO_CHANGE earns completion when justified.

## Record your observations

What improved? Did the model alter invalid/missing precedence? Was the refactor needed?

Use `evidence/lab_06_findings.md`. Record the prompt, context, exact response, local checks and one remaining limitation. Never record your API key.

## Solution — open after your first attempt

Keeping the existing explicit implementation is a valid solution:

```python
def evaluate_delivery(report_days, damaged_qty, evidence, window_days=7):
    if report_days is not None and report_days < 0:
        return "INVALID"
    if damaged_qty is not None and damaged_qty <= 0:
        return "INVALID"
    if report_days is None or damaged_qty is None or evidence is None:
        return "NEEDS_INFORMATION"
    if report_days > window_days:
        return "REQUIRES_REVIEW"
    if evidence is False:
        return "REQUIRES_REVIEW"
    return "ELIGIBLE"
```

Possible rationale: the small function already expresses each rule in order. Added classes or abstraction would increase complexity without a concrete benefit.

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
