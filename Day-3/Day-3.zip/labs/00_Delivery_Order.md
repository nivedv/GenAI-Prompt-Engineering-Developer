# Day 3 — Short Participant Labs

**Delivery sequence:** concept, trainer demo, matching participant lab, short evidence debrief.

Every lab is a separate Markdown document with instructions, completion checks and its solution inside the same document. Learners should attempt the task before opening the solution section. The labs are progressive; keep the same Day 3 project between them. There is no Day 2 code-folder prerequisite.

## Release order and timing

| Lab | Concept/demo | Participant lab | Total block | Deck slide |
|---|---:|---:|---:|---|
| 01 Playground to Python | 15 min | 15 min | 30 min | 4 |
| 02 Explanation and context | 15 min | 20 min | 35 min | 6 |
| 03 Bounded generation | 20 min | 25 min | 45 min | 7 |
| 04 Review and correction | 20 min | 25 min | 45 min | 8 |
| 05 Test writing and mutation | 20 min | 30 min | 50 min | 9 |
| 06 Refactoring | 10 min | 15 min | 25 min | 10 |
| 07 Documentation | 10 min | 20 min | 30 min | 10 |
| 08 Prompt library | 15 min | 25 min | 40 min | 11 |
| 09 Injection experiment | 15 min | 10 min | 25 min | 12 |
| 10 Hardening and retesting | 15 min | 20 min | 35 min | 13 |
| **Instruction/practice** | **155 min** | **205 min** | **360 min** | |
| Formative review | | | 120 min | 14 |
| **Learning time** | | | **480 min** | |

Breaks are additional. Install VDI prerequisites before class. If setup or model calls take longer, adjust the live schedule while preserving verification time. Slides 1–3 and 5 introduce the day and common prompt contract within the allocated trainer time.

## Formative review

Use 15 minutes preparation, 40 minutes paired walkthroughs, 35 minutes selected live walkthroughs, 20 minutes correction and 10 minutes final records. Require six prompt files, a running tool, independent tests, one context comparison and injection/hardening evidence. Award credit for resisted or blocked attacks when the experiment and evidence are sound.

## Technical references

Synthetic participant rules differ from the trainer's travel scenario. They are new Day 3 training material, not a reconstruction of unavailable Day 2 artifacts. Keep GPT-5 as the configured deployment. No Copilot, Claude or ChatGPT account is required for these exercises.

- [Azure OpenAI v1 API](https://learn.microsoft.com/en-us/azure/foundry/openai/api-version-lifecycle?tabs=key)
- [GPT-5 reasoning-model guidance](https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/reasoning)
- [Prompt Shields and document attacks](https://learn.microsoft.com/en-us/azure/foundry/openai/concepts/content-filter-prompt-shields)

Local reference implementations and tests are validated during preparation. Live Azure calls require the supplied environment and credentials; model answers and attack success are not predetermined.
