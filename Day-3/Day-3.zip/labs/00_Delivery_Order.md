# Participant order

Complete START_HERE.md once, then Labs 01–10 in numerical order. Each lab has its own steps, completion checks and reference solution. Use Foundry Chat Playground for every LLM task. Use VS Code for file editing and Python checks. No extension or API credentials are required locally.

The original policy and local tests are retained. Labs 01, 08 and 10 now use browser requests rather than an API application. This pack is the Playground adaptation of the earlier participant exercise, not the separate eight independent mini-labs.
