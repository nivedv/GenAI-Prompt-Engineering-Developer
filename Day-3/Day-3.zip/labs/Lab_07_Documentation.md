# Lab 07: Documentation

**Where:** Foundry Chat Playground for LLM requests. VS Code for files and local Python commands.

**Task:** Document the current verified checker.

**Expected outcome:** Accurate documentation with examples confirmed by local execution.

**Before starting:** Complete START_HERE.md and the preceding labs. Start terminal commands from the project root. Use the baseline system message unless this lab explicitly changes it.

## Step-by-step instructions

1. **Browser:** Start a fresh chat. Assemble one user message:

- Paste `prompts/06_document.txt`.
- Type `CONTRACT:` and paste `context/delivery_contract.txt`.
- Type `CURRENT FUNCTION:` and paste your root `delivery_check.py`.
- Type `LOCAL TEST COMMANDS:` and paste the following commands:

```powershell
.\.venv\Scripts\python.exe -m unittest test_delivery_acceptance -v
.\.venv\Scripts\python.exe -m unittest test_generated_delivery -v
```

2. Send. **VS Code:** Save the unmodified answer as `proposals/documentation_v1.md`.
3. Review it. It should explain the signature, supported types, ordered rules, labels, three examples and limitations. Reject claims about refunds, payments, storage or deployment that the code does not implement.
4. Save the reviewed document as root `DELIVERY_COMPONENT.md`.
5. Verify its examples in the terminal. For these reference examples, run:

```powershell
.\.venv\Scripts\python.exe -c "from delivery_check import evaluate_delivery; print(evaluate_delivery(7, 1, True))"
.\.venv\Scripts\python.exe -c "from delivery_check import evaluate_delivery; print(evaluate_delivery(8, 1, True))"
.\.venv\Scripts\python.exe -c "from delivery_check import evaluate_delivery; print(evaluate_delivery(3, 1, None))"
```

Expected outputs, in order: ELIGIBLE, REQUIRES_REVIEW, NEEDS_INFORMATION. If your document uses other examples, execute those exact arguments as well.
6. Correct any inaccurate wording in `DELIVERY_COMPONENT.md` and save. Keep the raw response for comparison.
7. In `evidence/lab_07_findings.md`, list one checked example and any corrected claim.

## How to verify completion

The root Markdown document exists. Its examples match execution, its test commands use this environment, and it accurately states the input scope.

## What to record

Open `evidence/lab_07_findings.md`. Write the request/prompt filename, response filenames, actual checks and one remaining limitation. Save it.

## Reference solution — read after your attempt

Reference documentation:

`evaluate_delivery(report_days, damaged_qty, evidence, window_days=7)` returns eligibility guidance. Within the supplied input scope, it checks known invalid values first, missing fields next, then late reporting and evidence. A request that satisfies the rules returns ELIGIBLE.

Examples:

- `(7, 1, True)` returns ELIGIBLE.
- `(8, 1, True)` returns REQUIRES_REVIEW.
- `(3, 1, None)` returns NEEDS_INFORMATION.

Inputs use the types in contract D3-1. The function does not parse strings or contact external systems. It does not approve refunds or payments. Invalid reporting windows and other input types are outside this lab's scope.

Run the two test commands listed above to check the supplied cases.

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
