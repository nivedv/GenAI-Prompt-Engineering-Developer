# Lab 06: Refactoring

**Where:** Foundry Chat Playground for LLM requests. VS Code for files and local Python commands.

**Task:** Assess a refactor while preserving the verified behaviour.

**Expected outcome:** Both suites pass before and after the accepted change, or a justified NO_CHANGE decision.

**Before starting:** Complete START_HERE.md and the preceding labs. Start terminal commands from the project root. Use the baseline system message unless this lab explicitly changes it.

## Step-by-step instructions

1. Back up the current checker and run both suites:

```powershell
Copy-Item delivery_check.py proposals/delivery_before_refactor.py
.\.venv\Scripts\python.exe -m unittest test_generated_delivery test_delivery_acceptance -v 2>&1 | Tee-Object -FilePath evidence/lab06_before.txt
```

2. **Browser:** Start a fresh chat. Build one user message in the order below. Paste each file's contents, not its name alone:

- First, copy the whole contents of `prompts/05_refactor.txt` from VS Code.
- Add a new line `CONTRACT:` and paste all of `context/delivery_contract.txt`.
- Add a new line `CURRENT FUNCTION:` and paste all of your root `delivery_check.py`.

3. Send the complete message. Do not paste the flawed seed or an old generation response.
4. **VS Code:** Save the full answer as `proposals/refactor_v1.txt`.
5. If the answer says NO_CHANGE, record its reason and leave the checker unchanged. That is a valid outcome for this already small function.
6. If it proposes a replacement, compare it with the contract. Check the function signature, labels, rule order and the treatment of missing values. Copy only an accepted replacement into `delivery_check.py` and save.
7. Run both suites:

```powershell
.\.venv\Scripts\python.exe -m unittest test_generated_delivery test_delivery_acceptance -v 2>&1 | Tee-Object -FilePath evidence/lab06_after.txt
```

8. If checks fail, restore using `Copy-Item proposals/delivery_before_refactor.py delivery_check.py` and rerun. Record that the proposal failed to preserve behaviour.
9. Complete `evidence/lab_06_findings.md`: accepted change, rejected change or justified NO_CHANGE, plus the actual results.

## How to verify completion

Before and after logs both show OK for the final accepted state. The contract is unchanged. More abstraction is not automatically an improvement.

## What to record

Open `evidence/lab_06_findings.md`. Write the request/prompt filename, response filenames, actual checks and one remaining limitation. Save it.

## Reference solution — read after your attempt

Keeping the existing explicit implementation is a valid solution:

```python
def evaluate_delivery(report_days, damaged_qty, evidence, window_days=7):
    if report_days is not None and report_days < 0:
        return "INVALID"
    if damaged_qty is not None and damaged_qty <= 0:
        return "INVALID"
    if report_days is None or damaged_qty is None or evidence is None:
        return "NEEDS_INFORMATION"
    if report_days > window_days:
        return "REQUIRES_REVIEW"
    if evidence is False:
        return "REQUIRES_REVIEW"
    return "ELIGIBLE"
```

Possible rationale: the small function already expresses each rule in order. Added classes or abstraction would increase complexity without a concrete benefit.

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
