# Lab 03 — Bounded Code Generation

**Participant time:** 25 minutes  
**Scenario:** Damaged Delivery Support  
**Workspace:** `C:\AgenticAI_Labs\Day3_Participant_Workflows`  
**Before this lab:** Complete Labs 01–02. Continue in the same Day 3 project.

## Concept and trainer demo

A bounded generation prompt fixes the interface, rules, allowed changes and verification method.

**Trainer demo:** Generate one function and verify it against independent acceptance cases.

## Your task

Generate `evaluate_delivery` and test it against the contract.

**Expected outcome:** A function that satisfies all eleven independent acceptance cases.

## Detailed instructions

1. Save `prompts/02_generate.txt`:

```text
Implement evaluate_delivery(report_days, damaged_qty, evidence, window_days=7).
Use the supplied contract exactly, including rule order.
Do not hard-code the reporting window or add dependencies.
Do not add refund approval, external APIs or string parsing.
Return only Python code without Markdown fences.
```

2. In a fresh Playground conversation, submit the task and the complete contract. Save the unmodified response as `proposals/generation_v1.txt`.
3. Inspect it, remove Markdown fences if necessary, and save the function in `delivery_check.py`.
4. Create `test_delivery_acceptance.py` from the independent tests in this document’s solution. Use those tests unchanged.
5. Run:

```powershell
python test_delivery_acceptance.py
```

6. If a case fails, submit the contract, proposed function and exact failure. Ask for a minimal correction while keeping tests and requirements fixed.
7. Repeat until checks pass. Preserve failed responses and test results.
## Supporting requirement

```text
SYNTHETIC DAY 3 DELIVERY CONTRACT, version D3-1
Function: evaluate_delivery(report_days, damaged_qty, evidence, window_days=7)
Inputs: report_days is an integer or None; damaged_qty is an integer or None;
evidence is a boolean or None; window_days is a positive integer.
Apply rules in this order:
D1: A known negative report_days or known damaged_qty <= 0 returns INVALID.
D2: Any missing report_days, damaged_qty or evidence returns NEEDS_INFORMATION.
D3: report_days > window_days returns REQUIRES_REVIEW.
D4: evidence is False returns REQUIRES_REVIEW.
D5: Otherwise return ELIGIBLE.
The reporting window is supplied at runtime. The default is 7 days.
Return exactly one of these labels. Do not approve refunds or payments.
No string parsing, currency conversion, external calls or dependencies.
Inputs outside the stated types and invalid window_days are outside this lab's scope.
```


## Completion check

The independent suite reports OK for eleven subtests within one test method. The default day-7 boundary and configurable day-10 window both work. A missing field does not silently become eligible.

## Record your observations

Did the model preserve rule order? Did it hard-code 7? Did it follow code-only formatting? Which test proves the reporting window is configurable?

Use `evidence/lab_03_findings.md`. Record the prompt, context, exact response, local checks and one remaining limitation. Never record your API key.

## Solution — open after your first attempt

Reference `delivery_check.py`:

```python
def evaluate_delivery(report_days, damaged_qty, evidence, window_days=7):
    if report_days is not None and report_days < 0:
        return "INVALID"
    if damaged_qty is not None and damaged_qty <= 0:
        return "INVALID"
    if report_days is None or damaged_qty is None or evidence is None:
        return "NEEDS_INFORMATION"
    if report_days > window_days:
        return "REQUIRES_REVIEW"
    if evidence is False:
        return "REQUIRES_REVIEW"
    return "ELIGIBLE"
```

Independent `test_delivery_acceptance.py`:

```python
import unittest
from delivery_check import evaluate_delivery


class DeliveryAcceptanceTests(unittest.TestCase):
    def test_contract(self):
        cases = [
            (3, 2, True, 7, "ELIGIBLE"),
            (7, 1, True, 7, "ELIGIBLE"),
            (8, 1, True, 7, "REQUIRES_REVIEW"),
            (None, 1, True, 7, "NEEDS_INFORMATION"),
            (3, None, True, 7, "NEEDS_INFORMATION"),
            (3, 1, None, 7, "NEEDS_INFORMATION"),
            (-1, 1, True, 7, "INVALID"),
            (3, 0, True, 7, "INVALID"),
            (3, 1, False, 7, "REQUIRES_REVIEW"),
            (8, 1, True, 10, "ELIGIBLE"),
            (None, 0, True, 7, "INVALID"),
        ]
        for days, qty, proof, window, expected in cases:
            with self.subTest(days=days, qty=qty, proof=proof, window=window):
                self.assertEqual(
                    evaluate_delivery(days, qty, proof, window), expected
                )


if __name__ == "__main__":
    unittest.main()
```

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
