# Lab 05: Test Writing and Mutation

**Where:** Foundry Chat Playground for LLM requests. VS Code for files and local Python commands.

**Task:** Generate tests from requirements and check their sensitivity.

**Expected outcome:** Tests that pass correct code, fail a deliberate boundary defect and pass after restoration.

**Before starting:** Complete START_HERE.md and the preceding labs. Start terminal commands from the project root. Use the baseline system message unless this lab explicitly changes it.

## Step-by-step instructions

1. **Terminal:** Confirm the current checker still passes:

```powershell
.\.venv\Scripts\python.exe -m unittest test_delivery_acceptance -v
```

2. **VS Code:** Open `playground_requests/lab05_tests.txt`. It includes the contract and test-writing task, but deliberately excludes the implementation.
3. **Browser:** Start a fresh chat. Send the entire request.
4. **VS Code:** Save the full raw response as `proposals/tests_v1.txt`. Inspect the test code. It must import `evaluate_delivery` from `delivery_check` and use unittest, not an uninstalled testing package.
5. Save only the reviewed Python test code as root `test_generated_delivery.py`. Remove Markdown fences and save.
6. Run:

```powershell
.\.venv\Scripts\python.exe -m unittest test_generated_delivery -v 2>&1 | Tee-Object -FilePath evidence/lab05_correct.txt
```

Expected: OK. If a test fails, check its expected value against the contract before changing the implementation.
7. Back up the correct implementation:

```powershell
Copy-Item delivery_check.py proposals/delivery_before_mutation.py
```

8. Open root `delivery_check.py`. Locate `if report_days > window_days:`. Change only `>` to `>=`. Save. This intentionally makes the boundary incorrect.
9. Rerun generated tests:

```powershell
.\.venv\Scripts\python.exe -m unittest test_generated_delivery -v 2>&1 | Tee-Object -FilePath evidence/lab05_mutated.txt
```

Expected: a failing assertion for the day-7 equality case. An import or syntax error is not the intended result.
10. Restore the entire correct file from the backup:

```powershell
Copy-Item proposals/delivery_before_mutation.py delivery_check.py
```

11. Run both suites:

```powershell
.\.venv\Scripts\python.exe -m unittest test_generated_delivery test_delivery_acceptance -v 2>&1 | Tee-Object -FilePath evidence/lab05_restored.txt
```

Expected: OK. If the generated tests missed the mutation, tell Playground that they lack a case proving equality is eligible. Request revised tests with the same contract, then repeat steps 6–11.
12. Recovery after an attempt: copy `solutions/lab05/test_generated_delivery.py` into root `test_generated_delivery.py`. Run it against correct and mutated code, then restore.

## How to verify completion

Three logs demonstrate pass, genuine boundary failure and restored pass. Record whether your generated tests needed improvement.

## What to record

Open `evidence/lab_05_findings.md`. Write the request/prompt filename, response filenames, actual checks and one remaining limitation. Save it.

## Reference solution — read after your attempt

The independent suite below is also a valid reference for `test_generated_delivery.py`. An AI-generated suite may use separate test methods instead.

```python
import unittest
from delivery_check import evaluate_delivery


class DeliveryAcceptanceTests(unittest.TestCase):
    def test_contract(self):
        cases = [
            (3, 2, True, 7, "ELIGIBLE"),
            (7, 1, True, 7, "ELIGIBLE"),
            (8, 1, True, 7, "REQUIRES_REVIEW"),
            (None, 1, True, 7, "NEEDS_INFORMATION"),
            (3, None, True, 7, "NEEDS_INFORMATION"),
            (3, 1, None, 7, "NEEDS_INFORMATION"),
            (-1, 1, True, 7, "INVALID"),
            (3, 0, True, 7, "INVALID"),
            (3, 1, False, 7, "REQUIRES_REVIEW"),
            (8, 1, True, 10, "ELIGIBLE"),
            (None, 0, True, 7, "INVALID"),
        ]
        for days, qty, proof, window, expected in cases:
            with self.subTest(days=days, qty=qty, proof=proof, window=window):
                self.assertEqual(
                    evaluate_delivery(days, qty, proof, window), expected
                )


if __name__ == "__main__":
    unittest.main()
```

The `(7, 1, True, 7)` case detects the mutation. After restoration it returns ELIGIBLE again.

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
