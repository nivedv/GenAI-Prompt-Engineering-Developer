# Lab 05 — Test Writing and Mutation

**Participant time:** 30 minutes  
**Scenario:** Damaged Delivery Support  
**Workspace:** `C:\AgenticAI_Labs\Day3_Participant_Workflows`  
**Before this lab:** Complete Lab 04 and preserve a verified `delivery_check.py`.

## Concept and trainer demo

Tests derived from requirements should expose a known defect, not merely agree with an implementation.

**Trainer demo:** Generate tests from a contract and deliberately mutate the equality boundary.

## Your task

Generate a test suite and prove it catches the day-7 boundary mistake.

**Expected outcome:** Generated tests pass correct code and fail the deliberate mutation.

## Detailed instructions

1. Save `prompts/04_tests.txt`:

```text
Write Python unittest tests for the supplied delivery contract.
Import evaluate_delivery from delivery_check.
Include normal, equality, missing and invalid inputs.
Test evidence=False, a changed reporting window and rule precedence.
Map cases to rule IDs in comments. Use only the standard library.
Do not alter implementation or contract. Return only Python source.
```

2. Submit the prompt and contract without the implementation. Save the response as `proposals/tests_v1.txt`.
3. Inspect and save `test_generated_delivery.py`. Run:

```powershell
python -m unittest test_generated_delivery -v
```

4. Preserve the correct implementation. Change only `report_days > window_days` to `report_days >= window_days` in `delivery_check.py`.
5. Run generated tests again. The equality case should fail. Save evidence.
6. Restore the comparison to `>` and rerun generated and independent suites.
7. If the generated suite missed the mutation, revise the prompt and rerun this experiment.

## Completion check

Evidence shows a passing correct implementation, failing mutation and passing restoration. The failure concerns the equality boundary, not a syntax or import mistake.

## Record your observations

Did generated tests detect the mutation? Did assertions come from the contract? Did any test introduce unsupported input types?

Use `evidence/lab_05_findings.md`. Record the prompt, context, exact response, local checks and one remaining limitation. Never record your API key.

## Solution — open after your first attempt

The independent suite below is also a valid reference for `test_generated_delivery.py`. An AI-generated suite may use separate test methods instead.

```python
import unittest
from delivery_check import evaluate_delivery


class DeliveryAcceptanceTests(unittest.TestCase):
    def test_contract(self):
        cases = [
            (3, 2, True, 7, "ELIGIBLE"),
            (7, 1, True, 7, "ELIGIBLE"),
            (8, 1, True, 7, "REQUIRES_REVIEW"),
            (None, 1, True, 7, "NEEDS_INFORMATION"),
            (3, None, True, 7, "NEEDS_INFORMATION"),
            (3, 1, None, 7, "NEEDS_INFORMATION"),
            (-1, 1, True, 7, "INVALID"),
            (3, 0, True, 7, "INVALID"),
            (3, 1, False, 7, "REQUIRES_REVIEW"),
            (8, 1, True, 10, "ELIGIBLE"),
            (None, 0, True, 7, "INVALID"),
        ]
        for days, qty, proof, window, expected in cases:
            with self.subTest(days=days, qty=qty, proof=proof, window=window):
                self.assertEqual(
                    evaluate_delivery(days, qty, proof, window), expected
                )


if __name__ == "__main__":
    unittest.main()
```

The `(7, 1, True, 7)` case detects the mutation. After restoration it returns ELIGIBLE again.

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
