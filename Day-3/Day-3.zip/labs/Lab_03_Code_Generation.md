# Lab 03: Code Generation

**Where:** Foundry Chat Playground for LLM requests. VS Code for files and local Python commands.

**Task:** Generate the checker and run independent acceptance checks.

**Expected outcome:** A saved function that passes the eleven stated acceptance cases.

**Before starting:** Complete START_HERE.md and the preceding labs. Start terminal commands from the project root. Use the baseline system message unless this lab explicitly changes it.

## Step-by-step instructions

1. **VS Code:** Open `delivery_check.py`. It initially contains a stub that raises NotImplementedError. You will replace this file, not create another checker elsewhere.
2. Open `playground_requests/lab03_generate.txt`. Read the requested signature and the complete contract included in it.
3. **Browser:** Start a fresh chat. Copy the entire request into the user-message box and send.
4. **VS Code:** Save the unmodified assistant response as `proposals/generation_v1.txt`.
5. Inspect the proposal: the function must be named `evaluate_delivery`, accept the four stated parameters, preserve D1–D5 order and use `window_days` rather than a hard-coded seven.
6. Copy only the reviewed Python function into the root `delivery_check.py`, replacing the stub. Remove Markdown fences if needed. Save with Ctrl+S.
7. Do not recreate or modify `test_delivery_acceptance.py`; it is already supplied. Run:

```powershell
.\.venv\Scripts\python.exe -m unittest test_delivery_acceptance -v 2>&1 | Tee-Object -FilePath evidence/lab03_acceptance.txt
```

8. Expected summary: `Ran 1 test` and `OK`. The one method contains eleven subtests.
9. If a test fails, save the failure first. Start a fresh Playground chat and paste: the contents of `prompts/02_generate.txt`, the contract, your current function and the complete failing test report. Add: `Correct only the function to satisfy the unchanged contract. Do not change the tests.`
10. Save the next response as `proposals/generation_v2.txt`, inspect it, update `delivery_check.py` and rerun the command. Continue only after OK.
11. If you are stuck after an attempt, use the recovery command below, then rerun the tests:

```powershell
Copy-Item solutions/lab03/delivery_check.py delivery_check.py
```

12. Write whether you needed a correction in `evidence/lab_03_findings.md`.

## How to verify completion

The test log exists and ends in OK. The initial stub is gone. The tests include day 7, a custom window of 10 and invalid/missing precedence.

## What to record

Open `evidence/lab_03_findings.md`. Write the request/prompt filename, response filenames, actual checks and one remaining limitation. Save it.

## Reference solution — read after your attempt

Reference `delivery_check.py`:

```python
def evaluate_delivery(report_days, damaged_qty, evidence, window_days=7):
    if report_days is not None and report_days < 0:
        return "INVALID"
    if damaged_qty is not None and damaged_qty <= 0:
        return "INVALID"
    if report_days is None or damaged_qty is None or evidence is None:
        return "NEEDS_INFORMATION"
    if report_days > window_days:
        return "REQUIRES_REVIEW"
    if evidence is False:
        return "REQUIRES_REVIEW"
    return "ELIGIBLE"
```

Independent `test_delivery_acceptance.py`:

```python
import unittest
from delivery_check import evaluate_delivery


class DeliveryAcceptanceTests(unittest.TestCase):
    def test_contract(self):
        cases = [
            (3, 2, True, 7, "ELIGIBLE"),
            (7, 1, True, 7, "ELIGIBLE"),
            (8, 1, True, 7, "REQUIRES_REVIEW"),
            (None, 1, True, 7, "NEEDS_INFORMATION"),
            (3, None, True, 7, "NEEDS_INFORMATION"),
            (3, 1, None, 7, "NEEDS_INFORMATION"),
            (-1, 1, True, 7, "INVALID"),
            (3, 0, True, 7, "INVALID"),
            (3, 1, False, 7, "REQUIRES_REVIEW"),
            (8, 1, True, 10, "ELIGIBLE"),
            (None, 0, True, 7, "INVALID"),
        ]
        for days, qty, proof, window, expected in cases:
            with self.subTest(days=days, qty=qty, proof=proof, window=window):
                self.assertEqual(
                    evaluate_delivery(days, qty, proof, window), expected
                )


if __name__ == "__main__":
    unittest.main()
```

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
