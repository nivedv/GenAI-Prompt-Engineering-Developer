# Lab 01: Playground Baseline and Local Setup

**Where:** Foundry Chat Playground for LLM requests. VS Code for files and local Python commands.

**Task:** Establish a working browser LLM response and local Python environment.

**Expected outcome:** A saved baseline response and a successful local Python run.

**Before starting:** Complete START_HERE.md and the preceding labs. Start terminal commands from the project root. Use the baseline system message unless this lab explicitly changes it.

## Step-by-step instructions

1. **VS Code:** Complete setup Sections A–B in START_HERE.md. Run:

```powershell
.\.venv\Scripts\python.exe hello_day3.py
```

Expected output: `Day 3 Python environment ready.` This checks Python locally; it does not call an LLM.
2. **VS Code:** Open `context/delivery_contract.txt`. Read rules D1–D5 in order. Note that ELIGIBLE is guidance, not refund approval.
3. **Browser:** Complete setup Section C. Select the course deployment, set the baseline system message, then start a fresh chat.
4. **VS Code:** Open `playground_requests/lab01_baseline.txt`. Copy the entire file using Ctrl+A and Ctrl+C.
5. **Browser:** Paste into the user-message box and send. This request already contains the contract and a question about damage reported after three days.
6. **VS Code:** Save the full response as `evidence/baseline_response.txt` using START_HERE Section E.
7. Compare the response with the contract. Does it explain eligibility without promising a refund?
8. Open `evidence/lab_01_findings.md`. Record the model/deployment name, response filename and your conclusion. Do not record credentials.

## How to verify completion

Python prints the readiness message. The saved response applies the supplied contract to 3 days, quantity 2 and evidence True. It should explain ELIGIBLE without approving payment.

## What to record

Open `evidence/lab_01_findings.md`. Write the request/prompt filename, response filenames, actual checks and one remaining limitation. Save it.

## Reference solution — read after your attempt

A valid response says the supplied facts satisfy the contract: reporting is within the seven-day window, the damaged quantity is positive and evidence is present. Exact wording can vary. No API call from Python is needed in this version.
