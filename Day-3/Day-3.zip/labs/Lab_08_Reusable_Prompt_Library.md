# Lab 08 — Reusable Prompt Library

**Participant time:** 25 minutes  
**Scenario:** Damaged Delivery Support  
**Workspace:** `C:\AgenticAI_Labs\Day3_Participant_Workflows`  
**Before this lab:** Complete Labs 01–07. Confirm all six developer prompt files exist.

## Concept and trainer demo

A reusable developer prompt combines a stable task with separately selected current context.

**Trainer demo:** Load a saved review prompt and source files through the Python API.

## Your task

Use your six prompt files from Python and connect the verified helper to an LLM explanation.

**Expected outcome:** A repeatable review request, saved proposal and visible local eligibility result.

## Detailed instructions

1. Confirm `prompts/01_explain.txt` through `prompts/06_document.txt` contain reusable task instructions without stale pasted source.
2. Create `developer_tasks.py` from the solution. It saves proposals; it does not execute them.
3. Run:

```powershell
python developer_tasks.py --prompt prompts/03_review.txt --context context/delivery_contract.txt context/delivery_seed.py --output evidence/api_review.md
```

4. Inspect the saved review. Repeat with `delivery_check.py` and a different output filename. Keep the prompt fixed while changing source.
5. Create `delivery_explainer.py` from the solution. Run:

```powershell
python delivery_explainer.py
```

6. Compare the model explanation with the local result. Check it does not claim refund approval.

## Completion check

The library contains all six tasks. API review files exist. The explanation preserves the visible local label. The baseline application still runs.

## Record your observations

Did the same prompt work with different files? Did the explanation contradict the local result? Which part of the tool is deterministic?

Use `evidence/lab_08_findings.md`. Record the prompt, context, exact response, local checks and one remaining limitation. Never record your API key.

## Solution — open after your first attempt

Create `developer_tasks.py`:

```python
import argparse
import json
from pathlib import Path
from llm_client import ask_model

parser = argparse.ArgumentParser()
parser.add_argument("--prompt", required=True)
parser.add_argument("--context", nargs="+", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()

task = Path(args.prompt).read_text(encoding="utf-8")
files = []
for name in args.context:
    path = Path(name)
    if path.name == ".env":
        raise SystemExit("Do not submit .env as source context.")
    files.append({"file": path.name, "content": path.read_text(encoding="utf-8")})
content = task + "\nSOURCE DATA:\n" + json.dumps(files, ensure_ascii=False)
answer = ask_model("Help with the developer task in the supplied request.", content)
output = Path(args.output)
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(answer, encoding="utf-8")
print("Saved proposal:", output)
```

Create `delivery_explainer.py`:

```python
from delivery_check import evaluate_delivery
from llm_client import ask_model

result = evaluate_delivery(8, 1, True, 7)
print("Verified local result:", result)
instructions = (
    "Explain the supplied local result in two sentences. Do not change it "
    "or invent policy. Eligibility guidance does not approve a refund."
)
print(ask_model(instructions, f"Delivery eligibility result: {result}"))
```

The local result should be REQUIRES_REVIEW. The model explanation is a separate output to inspect, not a replacement for the verified result. The `.env` filename check is a teaching safeguard, not a complete secret scanner.

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
