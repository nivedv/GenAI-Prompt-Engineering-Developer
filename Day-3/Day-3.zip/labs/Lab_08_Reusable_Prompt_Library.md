# Lab 08: Reusable Prompt Library

**Where:** Foundry Chat Playground for LLM requests. VS Code for files and local Python commands.

**Task:** Reuse a saved developer prompt in Chat Playground with different source contexts.

**Expected outcome:** Two reviews from the same template plus an explanation of a verified local result.

**Before starting:** Complete START_HERE.md and the preceding labs. Start terminal commands from the project root. Use the baseline system message unless this lab explicitly changes it.

## Step-by-step instructions

1. **VS Code:** Open `prompts`. Confirm it contains `01_explain.txt`, `02_generate.txt`, `03_review.txt`, `04_tests.txt`, `05_refactor.txt` and `06_document.txt`. These are the reusable library. Code context belongs in each request, not permanently inside these templates.
2. **Browser:** Start a fresh chat. Send `playground_requests/lab04_review.txt`. This reuses the review template with the defective seed. Save the response as `evidence/library_seed_review.md`.
3. Start another fresh chat. Assemble a user message by pasting `prompts/03_review.txt`, then `CONTRACT:` plus the contract, then `CURRENT FUNCTION:` plus your verified root `delivery_check.py`. Send it.
4. Save the second response as `evidence/library_current_review.md`. Check that it reviews the current function rather than reporting old seed defects. Any claimed defect needs a real counterexample.
5. **Terminal:** Run the supplied local demonstration:

```powershell
.\.venv\Scripts\python.exe local_decision_demo.py 2>&1 | Tee-Object -FilePath evidence/library_local_result.txt
```

Expected: `Local result: REQUIRES_REVIEW`.
6. **Browser:** Start a fresh chat. Send this message:

```text
Explain this verified local result in two sentences. Preserve the label.
Use only this fact: damage was reported after 8 days, the allowed window
is 7 days, quantity is 1, and evidence is True.
The local function returned REQUIRES_REVIEW.
Eligibility guidance does not approve a refund. Do not invent policy.
```

7. Save the response as `evidence/library_result_explanation.txt`. It should connect the late report to the review label, without overriding the local result.
8. Complete `evidence/lab_08_findings.md`: what remained constant in the prompt, what changed in the context, and whether the explanation preserved the result.

## How to verify completion

All six templates exist. Both reviews and the explanation are saved. Local result is REQUIRES_REVIEW. No API runner or extension was used.

## What to record

Open `evidence/lab_08_findings.md`. Write the request/prompt filename, response filenames, actual checks and one remaining limitation. Save it.

## Reference solution — read after your attempt

The seed review should identify real contract violations. A review of the correct current function should not repeat those seed-specific findings without evidence. The local demo prints REQUIRES_REVIEW for day 8 with a seven-day window. A valid explanation says the report is outside the allowed window and requires review; it does not approve or reject payment.
