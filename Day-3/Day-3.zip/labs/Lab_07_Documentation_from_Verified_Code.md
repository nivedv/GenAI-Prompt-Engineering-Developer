# Lab 07 — Documentation from Verified Code

**Participant time:** 20 minutes  
**Scenario:** Damaged Delivery Support  
**Workspace:** `C:\AgenticAI_Labs\Day3_Participant_Workflows`  
**Before this lab:** Complete Lab 06. Use final source, not the flawed seed.

## Concept and trainer demo

Documentation should describe the current verified implementation and its actual limits.

**Trainer demo:** Generate documentation and check every example against the function.

## Your task

Create a concise Markdown reference for the delivery helper.

**Expected outcome:** Documentation accurately covers the function, rules, examples and test commands.

## Detailed instructions

1. Save `prompts/06_document.txt`:

```text
Document the supplied function for an application developer.
Include signature, input scope, rule order, return labels, three examples,
limitations and the supplied test commands. Keep it under 400 words.
Do not invent refund approval, persistence, deployment or API integration.
Return Markdown. Mark unsupplied details as unknown.
```

2. Submit it with the contract, final source and these commands:

```powershell
python test_delivery_acceptance.py
python -m unittest test_generated_delivery -v
```

3. Save the result as `DELIVERY_COMPONENT.md`.
4. Execute each documented example in the terminal, for example:

```powershell
python -c "from delivery_check import evaluate_delivery; print(evaluate_delivery(7, 1, True))"
```

5. Correct unsupported claims or inaccurate examples and save the final document.

## Completion check

Examples match actual execution. The document does not claim approval, payments or capabilities absent from the code.

## Record your observations

Which sentence required correction? Did the model document an imagined capability? Were input limits clear?

Use `evidence/lab_07_findings.md`. Record the prompt, context, exact response, local checks and one remaining limitation. Never record your API key.

## Solution — open after your first attempt

Reference documentation:

`evaluate_delivery(report_days, damaged_qty, evidence, window_days=7)` returns eligibility guidance. Within the supplied input scope, it checks known invalid values first, missing fields next, then late reporting and evidence. A request that satisfies the rules returns ELIGIBLE.

Examples:

- `(7, 1, True)` returns ELIGIBLE.
- `(8, 1, True)` returns REQUIRES_REVIEW.
- `(3, 1, None)` returns NEEDS_INFORMATION.

Inputs use the types in contract D3-1. The function does not parse strings or contact external systems. It does not approve refunds or payments. Invalid reporting windows and other input types are outside this lab's scope.

Run the two test commands listed above to check the supplied cases.

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
