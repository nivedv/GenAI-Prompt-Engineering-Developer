# Lab 04 — Review and Correction

**Participant time:** 25 minutes  
**Scenario:** Damaged Delivery Support  
**Workspace:** `C:\AgenticAI_Labs\Day3_Participant_Workflows`  
**Before this lab:** Complete Lab 03. Keep the independent tests unchanged.

## Concept and trainer demo

A useful review identifies a requirement violation and a reproducible failing input.

**Trainer demo:** Run deliberately flawed code, review it, then verify a minimal correction.

## Your task

Review and correct the flawed delivery checker.

**Expected outcome:** A defect record with inputs, expected/actual labels, and before/after test evidence.

## Detailed instructions

1. Preserve your working function:

```powershell
Copy-Item delivery_check.py proposals/delivery_before_review.py
```

2. Create `context/delivery_seed.py` with this flawed code:

```python
def evaluate_delivery(report_days, damaged_qty, evidence, window_days=7):
    if report_days is None:
        return "ELIGIBLE"
    if report_days < 7:
        return "ELIGIBLE"
    return "REQUIRES_REVIEW"
```

3. Copy it into `delivery_check.py` and run the independent tests. Save the failures.
4. Create `prompts/03_review.txt`:

```text
Review the supplied source against the supplied contract.
For each defect give the source excerpt, rule ID, failing input,
expected result, actual result and minimal correction.
Do not claim you executed tests. Do not invent additional requirements.
Finish with a proposed corrected function.
```

5. Submit this task with `context/delivery_contract.txt` and the seed in a fresh conversation. Save the review.
6. Verify each reported defect. Inspect the correction, update `delivery_check.py` and rerun the independent suite.

## Completion check

The seed fails independent tests; the corrected function passes. Every accepted finding refers to a supplied rule and a reproducible example.

## Record your observations

Which review findings were factual? Did it add policy rules? Did it falsely claim local execution?

Use `evidence/lab_04_findings.md`. Record the prompt, context, exact response, local checks and one remaining limitation. Never record your API key.

## Solution — open after your first attempt

Reference defect checks:

| Input `(days, qty, evidence, window)` | Expected | Seed result | Issue |
|---|---|---|---|
| `(None, 1, True, 7)` | NEEDS_INFORMATION | ELIGIBLE | Missing information |
| `(7, 1, True, 7)` | ELIGIBLE | REQUIRES_REVIEW | Equality boundary |
| `(8, 1, True, 10)` | ELIGIBLE | REQUIRES_REVIEW | Hard-coded window |
| `(3, 0, True, 7)` | INVALID | ELIGIBLE | Invalid quantity |
| `(3, 1, False, 7)` | REQUIRES_REVIEW | ELIGIBLE | Missing evidence rule |

Use this reference correction if needed:

```python
def evaluate_delivery(report_days, damaged_qty, evidence, window_days=7):
    if report_days is not None and report_days < 0:
        return "INVALID"
    if damaged_qty is not None and damaged_qty <= 0:
        return "INVALID"
    if report_days is None or damaged_qty is None or evidence is None:
        return "NEEDS_INFORMATION"
    if report_days > window_days:
        return "REQUIRES_REVIEW"
    if evidence is False:
        return "REQUIRES_REVIEW"
    return "ELIGIBLE"
```

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
