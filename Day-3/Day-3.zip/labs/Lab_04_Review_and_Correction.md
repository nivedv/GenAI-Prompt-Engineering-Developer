# Lab 04: Review and Correction

**Where:** Foundry Chat Playground for LLM requests. VS Code for files and local Python commands.

**Task:** Review deliberately defective code, then correct it.

**Expected outcome:** A factual defect review and local before/after evidence.

**Before starting:** Complete START_HERE.md and the preceding labs. Start terminal commands from the project root. Use the baseline system message unless this lab explicitly changes it.

## Step-by-step instructions

1. **Terminal:** Back up the working checker:

```powershell
Copy-Item delivery_check.py proposals/delivery_before_review.py
```

2. Replace the root checker with the supplied defective seed:

```powershell
Copy-Item context/delivery_seed.py delivery_check.py
```

3. Run the independent checks and retain their expected failures:

```powershell
.\.venv\Scripts\python.exe -m unittest test_delivery_acceptance -v 2>&1 | Tee-Object -FilePath evidence/lab04_before.txt
```

FAILED is expected here. Syntax/import errors do not count as demonstrating the intended defect.
4. **VS Code:** Open `playground_requests/lab04_review.txt`. It already includes the review task, contract and defective source.
5. **Browser:** Start a fresh chat. Send the entire request.
6. **VS Code:** Save the full review and proposed correction as `evidence/lab04_review.md`.
7. Verify at least three findings. For each, check the quoted source, rule ID and example. The reference table at the end of this lab helps you assess the review.
8. Copy only the reviewed corrected function into root `delivery_check.py`. Leave the tests unchanged. Save.
9. Run:

```powershell
.\.venv\Scripts\python.exe -m unittest test_delivery_acceptance -v 2>&1 | Tee-Object -FilePath evidence/lab04_after.txt
```

10. Expected summary: OK. If not, send the unchanged contract, current function and exact failure to Playground for correction, as in Lab 03.
11. Recovery after an attempt: `Copy-Item solutions/lab04/delivery_check.py delivery_check.py`, then rerun.
12. Complete `evidence/lab_04_findings.md` with accepted findings and the before/after results.

## How to verify completion

Before log shows real assertion failures. After log shows OK. Accepted review findings correspond to actual contract violations.

## What to record

Open `evidence/lab_04_findings.md`. Write the request/prompt filename, response filenames, actual checks and one remaining limitation. Save it.

## Reference solution — read after your attempt

Reference defect checks:

| Input `(days, qty, evidence, window)` | Expected | Seed result | Issue |
|---|---|---|---|
| `(None, 1, True, 7)` | NEEDS_INFORMATION | ELIGIBLE | Missing information |
| `(7, 1, True, 7)` | ELIGIBLE | REQUIRES_REVIEW | Equality boundary |
| `(8, 1, True, 10)` | ELIGIBLE | REQUIRES_REVIEW | Hard-coded window |
| `(3, 0, True, 7)` | INVALID | ELIGIBLE | Invalid quantity |
| `(3, 1, False, 7)` | REQUIRES_REVIEW | ELIGIBLE | Missing evidence rule |

Use this reference correction if needed:

```python
def evaluate_delivery(report_days, damaged_qty, evidence, window_days=7):
    if report_days is not None and report_days < 0:
        return "INVALID"
    if damaged_qty is not None and damaged_qty <= 0:
        return "INVALID"
    if report_days is None or damaged_qty is None or evidence is None:
        return "NEEDS_INFORMATION"
    if report_days > window_days:
        return "REQUIRES_REVIEW"
    if evidence is False:
        return "REQUIRES_REVIEW"
    return "ELIGIBLE"
```

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
