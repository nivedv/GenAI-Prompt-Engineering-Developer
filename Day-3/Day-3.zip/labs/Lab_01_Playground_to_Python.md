# Lab 01 — Playground to Python

**Participant time:** 15 minutes  
**Scenario:** Damaged Delivery Support  
**Workspace:** `C:\AgenticAI_Labs\Day3_Participant_Workflows`  
**Before this lab:** Python and VS Code are installed. Trainer supplies Azure inference URL, deployment name and key through the approved lab channel.

## Concept and trainer demo

A coded application sends explicit instructions and context to the model. It does not inherit Playground conversation history.

**Trainer demo:** Show a new project, `.venv`, `.env`, and one model response. Trainer uses travel support; you build delivery support.

## Your task

Create the first Python version of the delivery assistant. No Day 2 folder or code is required.

**Expected outcome:** A response supported by a saved contract, with the Python interpreter inside this project’s `.venv`.

## Detailed instructions

1. Open a PowerShell terminal in VS Code. Run:

```powershell
New-Item -ItemType Directory -Force -Path C:\AgenticAI_Labs\Day3_Participant_Workflows
Set-Location C:\AgenticAI_Labs\Day3_Participant_Workflows
py -m venv .venv
```

2. Use **File → Open Folder** to open the new folder. Open a new terminal and run:

```powershell
.\.venv\Scripts\Activate.ps1
python -m pip install openai python-dotenv
New-Item -ItemType Directory -Force -Path prompts,context,proposals,evidence
python -c "import sys; print(sys.executable)"
```

3. Select **Ctrl+Shift+P → Python: Select Interpreter** and choose this project’s `.venv`. If activation is blocked, use `.\.venv\Scripts\python.exe` explicitly for installation and all runs.
4. Create `.env` in the project root, replacing placeholders:

```dotenv
AZURE_OPENAI_BASE_URL=https://YOUR-RESOURCE-NAME.openai.azure.com/openai/v1/
AZURE_OPENAI_API_KEY=YOUR-RESOURCE-KEY
AZURE_OPENAI_DEPLOYMENT=YOUR-ACTUAL-GPT5-DEPLOYMENT-NAME
```

Use the resource inference URL ending in `/openai/v1/`, not the project-management URL. The deployment name can differ from `gpt-5`. Hide the key during sharing.

5. Create `.gitignore` containing `.env`, `.venv/` and `__pycache__/` on separate lines. Create `requirements.txt` containing `openai` and `python-dotenv` on separate lines.
6. Save the supporting contract below as `context/delivery_contract.txt`. These are new synthetic Day 3 rules. They do not claim to reproduce your Day 2 policy.
7. Create `prompts/delivery_support.txt`:

```text
Answer using only the supplied delivery contract. Ask for missing information. Explain eligibility without claiming a refund or payment is approved. Keep the answer concise.
```

8. Create `llm_client.py` and `delivery_assistant.py` from the solution below. This starter is supplied; code generation is a later lab.
9. Run:

```powershell
python delivery_assistant.py --question "Damage reported after 3 days, 2 items damaged, photographic evidence available. What is the eligibility guidance?"
```

10. Inspect the response and `evidence/baseline_response.txt`.

## Supporting requirement

```text
SYNTHETIC DAY 3 DELIVERY CONTRACT, version D3-1
Function: evaluate_delivery(report_days, damaged_qty, evidence, window_days=7)
Inputs: report_days is an integer or None; damaged_qty is an integer or None;
evidence is a boolean or None; window_days is a positive integer.
Apply rules in this order:
D1: A known negative report_days or known damaged_qty <= 0 returns INVALID.
D2: Any missing report_days, damaged_qty or evidence returns NEEDS_INFORMATION.
D3: report_days > window_days returns REQUIRES_REVIEW.
D4: evidence is False returns REQUIRES_REVIEW.
D5: Otherwise return ELIGIBLE.
The reporting window is supplied at runtime. The default is 7 days.
Return exactly one of these labels. Do not approve refunds or payments.
No string parsing, currency conversion, external calls or dependencies.
Inputs outside the stated types and invalid window_days are outside this lab's scope.
```


## Completion check

The interpreter path contains `Day3_Participant_Workflows\.venv`. The response explains ELIGIBLE under the synthetic contract without claiming payment approval. The response file exists. Exact wording is not fixed.

## Record your observations

Which context did the Python call actually receive? Did it invent any refund policy? Did it ask for information already supplied?

Use `evidence/lab_01_findings.md`. Record the prompt, context, exact response, local checks and one remaining limitation. Never record your API key.

## Solution — open after your first attempt

Create `llm_client.py`:

```python
import os
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI

ROOT = Path(__file__).resolve().parent


def ask_model(instructions, content):
    load_dotenv(ROOT / ".env", override=True)
    client = OpenAI(
        base_url=os.environ["AZURE_OPENAI_BASE_URL"],
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        timeout=120.0,
        max_retries=0,
    )
    response = client.responses.create(
        model=os.environ["AZURE_OPENAI_DEPLOYMENT"],
        instructions=instructions,
        input=content,
    )
    if response.status != "completed" or not response.output_text.strip():
        raise RuntimeError(f"No completed answer. Status: {response.status}")
    return response.output_text
```

Create `delivery_assistant.py`:

```python
import argparse
from pathlib import Path
from llm_client import ask_model

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--question", required=True)
    args = parser.parse_args()
    prompt = (ROOT / "prompts/delivery_support.txt").read_text(encoding="utf-8")
    policy = (ROOT / "context/delivery_contract.txt").read_text(encoding="utf-8")
    answer = ask_model(prompt, "CONTRACT:\n" + policy + "\nQUESTION:\n" + args.question)
    (ROOT / "evidence/baseline_response.txt").write_text(answer, encoding="utf-8")
    print(answer)


if __name__ == "__main__":
    main()
```

If you see 401, check the resource key. For 404, check endpoint and actual deployment name. For connection errors, check the VDI network route. For missing packages, select the correct interpreter. Live inference requires your Azure configuration.

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
