# Lab 02: Explanation and Context

**Where:** Foundry Chat Playground for LLM requests. VS Code for files and local Python commands.

**Task:** Compare an explanation with an omitted helper and with that helper included.

**Expected outcome:** Two saved explanations and one identified difference in supported claims.

**Before starting:** Complete START_HERE.md and the preceding labs. Start terminal commands from the project root. Use the baseline system message unless this lab explicitly changes it.

## Step-by-step instructions

1. **VS Code:** Open `context/explanation/delivery_assistant.py`. This is source for explanation only. Do not execute it or install its SDK dependencies.
2. **VS Code:** Open `playground_requests/lab02_incomplete.txt`. It contains the explanation prompt and the assistant source, but no helper implementation.
3. **Browser:** Start a fresh chat with the baseline system message. Copy the complete request into the user-message box and send.
4. **VS Code:** Save the assistant response as `evidence/explain_incomplete.txt`.
5. Read what it says about `ask_model`. Its internals are absent from this request. Mark any guess about authentication, SDK use or API details as unsupported.
6. **VS Code:** Open `playground_requests/lab02_complete.txt`. It includes the same task plus both the assistant source and `llm_client.py`.
7. **Browser:** Start a fresh chat. Send the complete second request. Do not reuse the first conversation, because its earlier context would affect the comparison.
8. **VS Code:** Save the response as `evidence/explain_complete.txt`.
9. Open `context/explanation/llm_client.py`. Check each explanation claim against this actual source.
10. In `evidence/lab_02_findings.md`, write one newly supported claim and one unsupported guess from the first response, if there was one. A correctly identified unknown is also a valid result.

## How to verify completion

Both response files exist. The second explanation can support the model-call and environment-loading details from the helper. The first should identify those internals as unknown. Correct guessing still does not supply evidence.

## What to record

Open `evidence/lab_02_findings.md`. Write the request/prompt filename, response filenames, actual checks and one remaining limitation. Save it.

## Reference solution — read after your attempt

Reference explanation:

- `main` receives `--question` through argparse.
- The application reads instructions and contract from UTF-8 files.
- `ask_model` loads `.env`, creates an Azure-targeted OpenAI client and calls Responses using the deployment name.
- The client checks for a completed, non-empty answer.
- The application saves and prints the answer.
- The application does not execute model-generated code, approve payments or implement automatic conversation memory.

In the incomplete run, a valid answer identifies `ask_model` internals as unknown. If it describes the SDK or key loading without that helper being supplied, record an unsupported inference even if the guess happens to be correct.

Equivalent implementations are valid when they satisfy the contract. Model responses vary; the solution provides reference code or review criteria, not a claim that the model will return identical wording.
