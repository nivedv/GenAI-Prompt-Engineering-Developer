print("Day 3 Python environment ready.")
