import argparse
from pathlib import Path
from llm_client import ask_model

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--question", required=True)
    args = parser.parse_args()
    prompt = (ROOT / "prompts/delivery_support.txt").read_text(encoding="utf-8")
    policy = (ROOT / "context/delivery_contract.txt").read_text(encoding="utf-8")
    answer = ask_model(prompt, "CONTRACT:\n" + policy + "\nQUESTION:\n" + args.question)
    (ROOT / "evidence/baseline_response.txt").write_text(answer, encoding="utf-8")
    print(answer)


if __name__ == "__main__":
    main()
