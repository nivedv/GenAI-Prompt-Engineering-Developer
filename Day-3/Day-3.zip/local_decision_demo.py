from delivery_check import evaluate_delivery

print("Local result:", evaluate_delivery(8, 1, True, 7))
