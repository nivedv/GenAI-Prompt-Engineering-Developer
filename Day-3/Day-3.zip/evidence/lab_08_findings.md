# Lab 08 observations

Prompt used:

Context files:

Response file:

Local checks and actual results:

Remaining limitation:

Never record an API key.
