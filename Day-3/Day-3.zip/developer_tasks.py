import argparse
import json
from pathlib import Path
from llm_client import ask_model

parser = argparse.ArgumentParser()
parser.add_argument("--prompt", required=True)
parser.add_argument("--context", nargs="+", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()

task = Path(args.prompt).read_text(encoding="utf-8")
files = []
for name in args.context:
    path = Path(name)
    if path.name == ".env":
        raise SystemExit("Do not submit .env as source context.")
    files.append({"file": path.name, "content": path.read_text(encoding="utf-8")})
content = task + "\nSOURCE DATA:\n" + json.dumps(files, ensure_ascii=False)
answer = ask_model("Help with the developer task in the supplied request.", content)
output = Path(args.output)
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(answer, encoding="utf-8")
print("Saved proposal:", output)
