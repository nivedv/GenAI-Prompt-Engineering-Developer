# Lab 03: replace this starter with your reviewed generated implementation.
def evaluate_delivery(report_days, damaged_qty, evidence, window_days=7):
    raise NotImplementedError("Complete Lab 03 before using this function")
