# START HERE: Day 3 participant labs using Foundry Chat Playground

This is the detailed **Chat Playground version of the earlier 10 participant labs**. The delivery contract and local acceptance tests remain the same. Every LLM request is made in the browser. VS Code is only the text editor and place to run Python checks. You do not need the Foundry extension, an API runner, SDK packages or a local API key.

## A. Extract and open the correct folder

1. Download this ZIP to the VDI. In Windows File Explorer, right-click it and choose **Extract All**.
2. Extract it under `C:\AgenticAI_Labs`. The ZIP contains a folder named `Day3_Participant_Playground`.
3. Verify that `C:\AgenticAI_Labs\Day3_Participant_Playground\hello_day3.py` exists. If there are two nested folders with the same name, move the inner folder's contents up one level. Keep your earlier project unchanged.
4. Open VS Code. Select **File → Open Folder**. Select `C:\AgenticAI_Labs\Day3_Participant_Playground` and open it.
5. In the left Explorer panel, confirm you see `labs`, `prompts`, `context`, `playground_requests`, `solutions`, `evidence`, `proposals`, `delivery_check.py` and `test_delivery_acceptance.py`.

## B. Prepare Python once

1. In VS Code, select **Terminal → New Terminal**. Use a PowerShell terminal.
2. Run these commands one at a time:

```powershell
Set-Location C:\AgenticAI_Labs\Day3_Participant_Playground
py --version
py -m venv .venv
.\.venv\Scripts\python.exe hello_day3.py
```

Expected final output: `Day 3 Python environment ready.` If `py` is unavailable but `python` works, use `python -m venv .venv` instead. If neither exists, ask the trainer to enable the installed Python interpreter.

3. Press **Ctrl+Shift+P**, choose **Python: Select Interpreter**, and select this folder's `.venv\Scripts\python.exe`. If needed, select **Enter interpreter path** and browse to it.
4. All commands in this guide call `.\.venv\Scripts\python.exe` explicitly. You do not need to activate the environment or change PowerShell execution policy.
5. Before any command, check that your terminal is in this project folder. If uncertain, run the Set-Location command above again. No pip install is needed for these labs.

## C. Prepare Foundry Chat Playground once

1. In a browser, open the Foundry project URL supplied by the trainer and sign in using the assigned training account.
2. Open the **Chat Playground** for the trainer-approved deployed model. In some portal layouts, the same chat surface appears under the selected model's **Playground**. Use the trainer's model and deployment; do not create another deployment.
3. Locate the **System message** or **Instructions** field. Paste the contents of `prompts/baseline_system.txt` there. Apply/save the change if your page offers that control.
4. Use **New chat**, **Clear chat**, or the equivalent control to remove prior conversation history. This starts a new conversation, not a new project. Check that the model and system instructions are still correct.
5. Type `Reply with READY only.` into the user-message box and send. Check that a response arrives. If access or deployment selection is blocked, ask the trainer to resolve it before continuing.
6. Start a fresh chat again. Keep the same deployment and other model settings for comparisons. Use the baseline system instruction for Labs 01–09. Lab 10 explicitly changes it.

Portal labels vary between Foundry layouts. Find the chat's system/instructions field and its user-message box. These are different inputs. You do not need to use an Agent, an extension or **View code**.

## D. How to send a supplied request

Whenever a lab says **send request X**, do this:

1. In VS Code Explorer, open the specified `.txt` file under `playground_requests`.
2. Click inside that file, press **Ctrl+A**, then **Ctrl+C**. Copy the contents, not the filename.
3. Switch to Chat Playground. Start a fresh chat when the step asks for one.
4. Click the **user-message box**, press **Ctrl+V**, then send. The supplied request already includes the task and required source text. Do not add `.env`, credentials or unrelated files.
5. Wait for the response. Copy only the assistant's response using the response's Copy control, or by selecting its text.
6. Save it using the procedure below. Save each result before clearing the conversation.

## E. How to save a response or Python file

1. In VS Code, select **File → New Text File** or press **Ctrl+N**.
2. Paste the copied response. Press **Ctrl+Shift+S** and save under the exact relative path stated in the lab. For example, `evidence\baseline_response.txt` means a file inside this project's `evidence` folder.
3. Preserve an unmodified response in `proposals` or `evidence` before editing it.
4. For a runnable `.py` file, copy only Python code. Remove a leading ```python line and a closing ``` line if the response includes Markdown fences. Exclude explanatory paragraphs from the Python file.
5. Save with **Ctrl+S** before running a command. `delivery_check.py` and `test_generated_delivery.py` belong in the project root, alongside `test_delivery_acceptance.py`.
6. Inspect generated code before execution. The lab expects small functions or unittest tests with no shell commands, network calls or package installation.

## F. Which files are supplied and which you produce

| Supplied | What you do |
| --- | --- |
| `prompts/*.txt` | Read and reuse the instructions. Do not recreate them. |
| `playground_requests/*.txt` | Copy complete static requests into Chat Playground. |
| `context/delivery_contract.txt` | Read the exact synthetic requirements. Do not change them. |
| `context/delivery_seed.py` | Review this deliberately defective source. |
| `delivery_check.py` | Replace its initial stub with your reviewed generated function in Lab 03. |
| `test_delivery_acceptance.py` | Run these independent checks unchanged. |
| `solutions/*` | Consult after attempting the task, or use the stated recovery command. |
| `evidence/lab_XX_findings.md` | Fill in actual observations. |

You produce `test_generated_delivery.py`, documentation, responses and test logs. Supplied requests for refactoring and documentation cannot know your current generated source: those labs tell you exactly how to add it.

## G. What a successful test result means

`python -m unittest ...` prints its report in the terminal. `OK` means the checks in that run passed. `FAILED` means an assertion failed. `ERROR` usually means code could not load or run. Lab 03's independent suite has **one test method containing eleven subtests**, so `Ran 1 test ... OK` is the expected successful summary.

Passing these checks is evidence for the stated cases, not proof of every possible input. The model's claim that it ran tests does not replace a local test report.

## H. Lab order and evidence

Complete Labs 01–10 in numerical order. Open one document from `labs` at a time. At the end of each lab, fill its findings file with the prompt/request filename, response filename, actual checks and one observation. Do not put API keys in evidence.

For a missing prerequisite, use that lab's stated recovery command. Do not copy a reference solution before your first attempt unless the trainer asks you to recover.

## I. Common fixes

| What you see | What to do |
| --- | --- |
| `.venv\Scripts\python.exe` not found | Check the terminal folder, then create `.venv` using Section B. |
| `ModuleNotFoundError: delivery_check` | Save `delivery_check.py` in the project root and run the command from that root. |
| `NotImplementedError` | The supplied stub is still present. Complete Lab 03 or use its recovery command. |
| `SyntaxError` mentioning backticks | Remove Markdown fences from the `.py` file and save. |
| `No module named test_generated_delivery` | Save `test_generated_delivery.py` in the root during Lab 05. |
| Generated function fails a test | Keep tests unchanged. Send the contract, current function and exact failure back to Playground for correction. |
| No model response or content-filter error | Save the observed error and ask the trainer. Do not claim success or change deployment protections to force an attack outcome. |
| Different response wording | Compare requirements and actual behaviour, not exact prose. |

## Reference for the Playground interface

Microsoft Learn: [Get answers in Chat Playground](https://learn.microsoft.com/en-us/azure/foundry-classic/quickstarts/get-started-playground?azure-portal=true). The project and deployed model must already be accessible to your training account.
