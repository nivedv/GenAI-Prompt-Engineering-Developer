# Delivery eligibility component

`evaluate_delivery(report_days, damaged_qty, evidence, window_days=7)` applies synthetic contract D3-1. Known invalid values take priority over missing fields; missing fields take priority over the reporting window and evidence checks.

Examples: `(7, 1, True)` → ELIGIBLE; `(8, 1, True)` → REQUIRES_REVIEW; `(3, 1, None)` → NEEDS_INFORMATION.

Inputs are integer days and quantity, boolean evidence, or None. The window is a positive integer. Other types and invalid windows are outside scope. There are no external calls, payments or refund approvals.

Verification: `python -m unittest test_delivery_acceptance -v`. In Lab 05, also run `python -m unittest test_generated_delivery -v` after creating the generated test file.
