import unittest
from delivery_check import evaluate_delivery


class DeliveryAcceptanceTests(unittest.TestCase):
    def test_contract(self):
        cases = [
            (3, 2, True, 7, "ELIGIBLE"),
            (7, 1, True, 7, "ELIGIBLE"),
            (8, 1, True, 7, "REQUIRES_REVIEW"),
            (None, 1, True, 7, "NEEDS_INFORMATION"),
            (3, None, True, 7, "NEEDS_INFORMATION"),
            (3, 1, None, 7, "NEEDS_INFORMATION"),
            (-1, 1, True, 7, "INVALID"),
            (3, 0, True, 7, "INVALID"),
            (3, 1, False, 7, "REQUIRES_REVIEW"),
            (8, 1, True, 10, "ELIGIBLE"),
            (None, 0, True, 7, "INVALID"),
        ]
        for days, qty, proof, window, expected in cases:
            with self.subTest(days=days, qty=qty, proof=proof, window=window):
                self.assertEqual(
                    evaluate_delivery(days, qty, proof, window), expected
                )


if __name__ == "__main__":
    unittest.main()
