"""Offline tests use synthetic vectors. They do not validate Azure/model quality."""
import importlib.util
import tempfile
import unittest
from pathlib import Path
import numpy as np
import rag

class PipelineTests(unittest.TestCase):
    def test_section_preserves_rule_and_exception(self):
        chunks = rag.load_chunks(rag.ROOT/'documents')
        evidence = [c for c in chunks if c['file'].startswith('01_') and
                    'Section 7:' in c['text']]
        self.assertEqual(len(evidence), 1)
        self.assertIn('30 minutes', evidence[0]['text'])
        self.assertIn('irreversible database migration', evidence[0]['text'])
        self.assertIn('Version: 2.4', evidence[0]['text'])

    @unittest.skipUnless(importlib.util.find_spec('chromadb'), 'Chroma not installed')
    def test_retrieval_recovers_known_evidence_and_maps_source(self):
        chunks = [{'id':'a','file':'Orders.txt','part':1,'text':'Orders rule'},
                  {'id':'b','file':'Payments.txt','part':2,'text':'Payments rule'}]
        with tempfile.TemporaryDirectory() as tmp:
            rag.persist(chunks, np.array([[1,0],[0,1]], dtype='float32'),tmp,{})
            hits = rag.retrieve('Orders', tmp, 1,
                                embed_fn=lambda _: np.array([[1,0]],dtype='float32'))
            self.assertEqual(hits[0]['file'],'Orders.txt')
            self.assertAlmostEqual(hits[0]['score'],1)
            prompt, kept = rag.assemble('Can I roll back?',hits)
            self.assertIn('[S1] Orders.txt part 1',prompt)
            self.assertEqual(kept[0]['id'],'a')

    @unittest.skipUnless(importlib.util.find_spec('chromadb'), 'Chroma not installed')
    def test_embedding_space_dimension_mismatch_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            rag.persist([{'text':'x'}],np.array([[1,0]],dtype='float32'),tmp,{})
            with self.assertRaisesRegex(ValueError,'dimensions'):
                rag.retrieve('x',tmp,1,embed_fn=lambda _:np.array([[1,0,0]],dtype='float32'))

    def test_context_does_not_cut_passage_mid_exception(self):
        hits = [{'source':'S1','file':'x','part':1,'text':'a'*17000},
                {'source':'S2','file':'y','part':2,'text':'rule and exception'}]
        prompt, included = rag.assemble('question',hits)
        self.assertEqual([h['source'] for h in included], ['S2'])
        self.assertIn('rule and exception',prompt)
        self.assertNotIn('[S1]',prompt)

if __name__=='__main__': unittest.main()
