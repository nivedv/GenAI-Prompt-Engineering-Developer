# Hands-on Lab 2: Ground the Running Developer Tool with RAG

**Duration:** 90–120 minutes. **Stack:** Python 3.11+, Azure OpenAI embeddings, local persistent Chroma collection, existing Azure-hosted GPT-5 deployment. **Authentication:** API keys held in local `.env` configuration.

## User story

As Maya, the on-call developer, I want the developer tool to explain Orders API v2 rollback eligibility from its approved runbooks, with supporting source references, so I can identify required checks before requesting a recovery decision.

The documents are fictional and supplied in `documents/`. The normal window is 30 minutes, subject to incident commander approval and no executed irreversible migration. An irreversible migration blocks normal rollback even inside that window. The Payments file is a distractor with a different policy.

## What you build

```mermaid
flowchart TD
 D[Supplied runbooks] --> C[Chunks with source metadata]
 C --> E[Azure embedding deployment]
 E --> I[Chroma collection]
 Q[Question] --> V[Query embedding]
 V --> R[Top-k retrieval]
 I --> R
 R --> P[Evidence and question]
 P --> G[Azure GPT-5]
 G --> A[Answer with source labels]
```

The CLI is a small running developer tool. It exposes `build`, `retrieve`, `baseline`, and `ask`. If you already have a Python tool, add the retrieval and assembly functions to its model-call path as shown in Activity 7.

This lab does not need Azure AI Search or the retiring Chat Playground “Add your data” feature. Chroma stores the passages, vectors and metadata locally and performs vector search. Azure hosts the embedding and generation models.

## Files

| File | Purpose |
|---|---|
| `rag.py` | Runnable ingestion, retrieval, prompt assembly, generation and traces |
| `documents/` | Four fictional source documents |
| `.env.example` | Connection settings template |
| `requirements.txt` | Dependency ranges |
| `test_offline.py` | Offline checks for evidence preservation, retrieval/source mapping and context guards |

## Activity 1: Prepare the environment

1. Extract the package to a folder you can edit.
2. Open that folder in VS Code and open its terminal.
3. Create a virtual environment.

Windows PowerShell:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
```

macOS/Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cp .env.example .env
```

Use the virtual environment's Python for every command below. Commands are shown as `python`; on Windows use `.\.venv\Scripts\python.exe`, and on macOS/Linux use `.venv/bin/python` if the environment is not activated.

4. In Foundry, locate your **deployment names**, API endpoint, and key. Configure `.env` locally.
5. Use the Azure OpenAI resource endpoint, for example `https://my-resource.openai.azure.com`, not the project `/api/projects/...` endpoint. The code appends `/openai/v1/`.
6. Set `AZURE_OPENAI_CHAT_DEPLOYMENT` to the actual GPT-5 deployment name.
7. Deploy or select a separate embedding model, such as `text-embedding-3-small`, and set its actual deployment name.
8. If embeddings are deployed in a different resource, set the two optional embedding endpoint/key variables too.

Do not paste keys into chat, code, screenshots, or source control. `.gitignore` excludes `.env`. This exercise uses only fictional public-to-the-class data. The code sends the document text to Azure for embeddings and sends retrieved evidence for generation.

**Use your installed Chroma:** run `python -c "import chromadb; print(chromadb.__version__)"` in the training environment. This code targets Chroma 1.x and uses its collection `configuration` API. If Chroma is already compatible, no separate database installation or server is needed. The pip command satisfies declared dependencies and may install missing ones. If an older version must remain unchanged, use a separate lab virtual environment rather than changing a shared environment.

The collection uses `embedding_function=None`. Azure creates the document and query embeddings explicitly, preventing Chroma from silently using a different default embedding model.

## Activity 2: Inspect and chunk the documents

1. Read Orders Runbook Section 7.
2. Find the 30-minute rule, required approval, and migration exception.
3. Read the database policy and checklist. Identify facts that describe policy versus facts that require a live system.
4. Read `load_chunks()` in `rag.py`.
5. Explain why the document header accompanies every section and why Section 7 remains one chunk.

Default chunking uses section boundaries for these small files. It is intentionally suited to this supplied collection. It does not impose a general maximum token size on arbitrary documents. Larger sources require a token-aware splitter that respects model input limits and preserves exceptions.

**Completion evidence:** the Section 7 chunk contains both the rule and exception, source filename, version, and section number.

## Activity 3: Build the vector index

```bash
python rag.py build
```

Open `store/chunks.json` and `store/manifest.json`. Note the actual chunk count and embedding dimensions. The `store/chroma/` directory contains the persistent Chroma data. The collection name is `orders-runbooks`. Rebuilding replaces only that lab collection in the selected store and removes obsolete chunks. Use a new store path for experiments.

The collection uses cosine distance. The code supplies normalized Azure vectors, returns Chroma distance (smaller is closer), and also reports `score = 1 - distance` (larger is closer). Local Chroma uses approximate nearest-neighbour indexing. This differs from the previous exact FAISS index. Query and document embeddings must use the same embedding deployment/space. Rebuild after changing the embedding deployment or its underlying model version; matching dimensions alone do not establish compatibility.

## Activity 4: Inspect retrieval before generation

```bash
python rag.py retrieve "What conditions govern Orders API v2 rollback after an irreversible migration?" --k 4
```

1. Inspect each returned `text`, `file`, `part`, `source` and `distance` and derived similarity `score`.
2. Confirm whether the required exception appears.
3. Check whether Payments content appears and whether it displaces useful evidence.
4. Repeat using “undo a release” instead of “rollback”.

A cosine score is a ranking signal, not a confidence percentage. The lab has no calibrated no-answer threshold. It retrieves nearest neighbours even for an unanswerable question, then instructs the generation model to acknowledge insufficient evidence.

## Activity 5: Compare baseline and RAG

Start with the baseline:

```bash
python rag.py baseline "Orders API v2 deployed 12 minutes ago and an irreversible database migration executed. Is normal rollback eligible?"
```

Then ground the tool:

```bash
python rag.py ask "Orders API v2 deployed 12 minutes ago and an irreversible database migration executed. Is normal rollback eligible? Cite the policy and explain the escalation." --k 4
```

Inspect the trace under `runs/`. It records retrieved chunks, source mapping, response status, token usage where available, and total time. It contains source text, so use fictional data only and protect traces in any real implementation.

Expected grounded behaviour: normal rollback is blocked by the migration exception, despite being inside the window. Escalation involves the database lead and incident commander. Wording is variable; do not require a memorized answer.

The model may answer the baseline correctly using general reasoning. That does not demonstrate knowledge of this internal policy or verifiable retrieval. Compare source support as well as the final conclusion.

## Activity 6: Verify source references and missing facts

```bash
python rag.py ask "Which release is running in Orders API production now and did its database migration execute?" --k 4
python rag.py ask "What is the Orders API v2 rollback window?" --k 4
python rag.py ask "Migration status is unknown. Can Maya assume normal rollback is eligible?" --k 4
```

Expected behaviour:

- No invented live release ID or execution status.
- Orders uses 30 minutes with conditions, rather than Payments' 10 minutes.
- Unknown migration status requires verification before confirming eligibility.

Open the source named beside each claim and check the passage. Labels such as `[S1]` resolve to the filenames and parts printed by the tool. These are application references, not automatically clickable citations.

The code rejects unknown source labels and flags responses without citations. It does **not** prove that a known source supports the claim. Perform semantic claim-to-passage review. If the response is incomplete because its output allowance ran out, inspect `status` and increase the output budget if appropriate; a partially generated answer is not a passing test.

## Activity 7: Ground your existing Python tool

Keep your existing question input. Replace its direct model call with:

```python
from pathlib import Path
from rag import retrieve, generate

question = user_question  # Your existing input variable
hits = retrieve(question, Path("store"), k=4)
result = generate(question, hits)
print(result["answer"])
print(result["sources"])
```

Use the real path to the saved index when your tool has another working directory. Keep the same `.env` settings. `generate()` is where the supplied evidence enters the request to the model. Leave `baseline` available for comparison during the lab.

**Completion evidence:** your existing tool returns a source-backed answer and exposes its supporting filenames/sections.

## Activity 8: Break retrieval and measure the change

### Experiment A: Too few results

Run the same cross-document question with `--k 1` and `--k 4`:

```bash
python rag.py ask "What must Maya verify for Orders API v2 recovery, and who handles an executed irreversible migration?" --k 1
python rag.py ask "What must Maya verify for Orders API v2 recovery, and who handles an executed irreversible migration?" --k 4
```

Inspect retrieved evidence and answer completeness. A difference is possible, not guaranteed. If both pass, explain that the first chunk already contained sufficient information. The lesson is to measure rather than manufacture a failure.

### Experiment B: Poor boundaries

Build a separate deliberately small-word index:

```bash
python rag.py build --mode words --size 25 --overlap 0 --store store-small
python rag.py ask "Orders API v2 deployed 12 minutes ago and an irreversible migration executed. Is normal rollback eligible?" --store store-small --k 1
```

Word counts here are exercise parameters, **not token counts or enterprise defaults**. Compare against the section baseline. Search for where the rule and exception landed. Do not overwrite the good index.

### Experiment C: Unnecessary context

Repeat a simple window question with `--k 1`, `--k 4`, and `--k 10`. Note that k is capped at the actual number of chunks. Look for irrelevant evidence, added usage and latency, and whether the answer improves. Record actual observations, not expected numeric scores.

| Run | Index/mode | k | Required evidence found? | Exception retained? | Unsupported claim? | Input/output usage | Seconds |
|---|---|---:|---|---|---|---|---:|
| Baseline | No retrieval | — | — | | | | |
| Grounded | Sections | 4 | | | | | |
| Few results | Sections | 1 | | | | | |
| Poor boundaries | 25 words / no overlap | 1 | | | | | |

Model outputs vary. Repeat important cases and judge multiple runs before claiming an improvement. Keep the question, deployment, and other settings fixed when comparing one retrieval change.

## Activity 9: Run offline checks

```bash
python -m unittest -v test_offline.py
```

These tests check section preservation, Chroma retrieval with synthetic vectors when Chroma is installed, source mapping, incompatible dimensions, and whole-passage context packing. They make no Azure calls and do not validate semantic embeddings or GPT-5 responses.

## Troubleshooting

| Failure | Check |
|---|---|
| Authentication failure | Correct resource key and endpoint pairing, no placeholder values |
| Deployment not found | Actual deployment name, including case, and correct Azure resource |
| Build fails | Embedding deployment exists, network access and quota, dependency availability |
| Chroma import fails | Chroma is installed in the Python environment running the command |
| Ask reports dimension mismatch | Rebuild with the current embedding deployment |
| Output empty/incomplete | Response status, available output budget and deployment support |
| Exception absent | Inspect chunks and retrieved passages before changing prompt |
| Unsupported reasoning parameter | Verify GPT-5 deployment selected; this code targets GPT-5, not arbitrary chat models |
| Generic error message | Inspect configuration locally. Do not print keys or whole API request bodies |

## Completion criteria and production boundary

Submit code changes, one grounded trace, one missing-answer trace, and the experiment table. Explain the first stage where evidence was lost in any failing run.

The feature passes the lab when it preserves the rule and exception, keeps service scope, supplies valid supporting references, and avoids inventing live status. It must never authorize or execute rollback.

This is a teaching pipeline, without document-level authorization, hybrid retrieval, semantic reranking, calibrated abstention, multi-user isolation, or a full token-budget manager. Apply those controls before adapting it to sensitive enterprise data. API keys are convenient for this authorized classroom workflow; real hosting needs an approved secrets/access design.

## Official sources

- [Microsoft: Azure OpenAI endpoint configuration](https://learn.microsoft.com/en-us/azure/foundry-classic/openai/how-to/switching-endpoints)
- [Microsoft: generate embeddings](https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/embeddings)
- [Microsoft: Responses API reference](https://learn.microsoft.com/en-us/rest/api/microsoft-foundry/azureopenai/responses)
- [Microsoft: RAG design and evaluation](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/rag/rag-solution-design-and-evaluation-guide)
- [Microsoft: RAG prompt assembly](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/rag/rag-prompt-engineering)
- [Chroma: persistent Python client](https://docs.trychroma.com/reference/python)
- [Chroma: collection configuration](https://docs.trychroma.com/docs/collections/configure)
- [Chroma: querying supplied embeddings](https://docs.trychroma.com/docs/querying-collections/query-and-get)

Checked 8 October 2026. Package dependencies are compatibility ranges, not a fully locked environment. Offline chunking/context tests were run while updating the package. The Chroma integration tests skip when Chroma is absent. Chroma is not installed in the authoring environment, so local Chroma execution must be checked in your prepared training environment. Azure calls and model behaviour must be rehearsed using your own deployment and credentials.
