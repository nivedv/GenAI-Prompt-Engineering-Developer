# Leave Policy

## Overview
This policy applies to all permanent employees of the Company. The leave year runs from 1 April to 31 March. Leave is a benefit that must be approved by the reporting manager; it is not an entitlement to be taken without approval.

## Earned leave
Employees accrue 1.5 days of earned leave per month, credited on the last working day of each month. Accrual starts from the date of joining. Employees on probation accrue leave but may use it only with HR approval. Earned leave carries forward up to a maximum of 30 days into the next leave year. Any balance above 30 days lapses on 31 March.

## Sick leave
Employees receive 12 days of sick leave per year, credited on 1 April. Sick leave does not carry forward and cannot be encashed. A medical certificate is required when sick leave exceeds 2 consecutive days.

## Casual leave
Employees receive 8 days of casual leave per year, credited on 1 April. Casual leave may be taken for a maximum of 2 consecutive days at a time and cannot be combined with sick leave. Unused casual leave lapses on 31 March.

## How to apply
Apply for leave through the HR portal. For leave longer than 2 days, apply at least 3 working days in advance. For leave of 1 or 2 days, apply as early as possible. The reporting manager approves or rejects the request within 2 working days. Any absence that has not been approved is treated as loss of pay.

## Maternity and paternity leave
Maternity leave is 26 weeks for the first two children, and 12 weeks thereafter. Paternity leave is 10 working days and must be taken within 6 months of the birth of the child. Both require a written application to HR with supporting documents.

## Leave encashment
On exit, the balance of earned leave up to a maximum of 30 days is encashed at final settlement, calculated on basic salary. Sick leave and casual leave are not encashable.
