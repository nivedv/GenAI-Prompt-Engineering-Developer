# Software Request Process

## Overview
All software requests are raised as a ticket on the ServiceDesk portal under the category Software. The ticket must state the business reason, the number of users and the expected duration of use.

## Software on the approved catalogue
For software already on the approved catalogue, the ticket goes to the reporting manager for approval. After approval, the software is installed or made available within 5 working days. Common examples are the office suite, the PDF editor and the diagramming tool.

## Software not on the catalogue
Software that is not on the catalogue needs a security and legal review before purchase or use. The review takes up to 10 working days and covers data handling, licence terms, vendor risk and integration with company systems. The requester may be asked to provide a vendor questionnaire. Work must not start with unreviewed software, even on a free trial.

## Cost approvals
Licences costing up to ₹50,000 per year are approved by the department head. Licences above ₹50,000 per year need the additional approval of the IT head and the finance head. Purchases are made only by the procurement team and never on a personal card.

## Open source and AI tools
Open source packages used in company products and any AI tool follow the same review as new software, with an extra check of licence obligations and of where data is sent. Only tools on the approved AI list may be used with company data.

## Renewals and removal
The business owner of each licence confirms in writing every year whether it should be renewed. Unused licences are removed after 60 days of inactivity. When an employee leaves, their licences are returned to the pool.
