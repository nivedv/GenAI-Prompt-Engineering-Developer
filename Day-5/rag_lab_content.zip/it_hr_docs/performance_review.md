# Performance Review Policy

## Review cycle
The performance year runs from 1 April to 31 March. Goals are set with the manager in April. A mid-year check-in takes place in October, and the annual review is held in March and April. Employees who joined less than 3 months before the end of the year are reviewed in the next cycle.

## Rating scale
Ratings use a scale of 1 to 5.

| Rating | Meaning |
| --- | --- |
| 1 | Needs significant improvement |
| 2 | Partially meets expectations |
| 3 | Meets expectations |
| 4 | Exceeds expectations |
| 5 | Outstanding |

## Calibration
After managers propose ratings, a calibration meeting of department heads and HR reviews them for consistency across teams. Ratings may change in calibration, and the manager explains the final rating to the employee.

## Appeals
An employee who disagrees with the final rating may appeal in writing to the HR business partner within 15 days of the rating being communicated. HR reviews the case with a second-level manager and gives a decision within 10 working days. The decision after appeal is final.

## Increments and promotions
Salary increments and promotions are effective from 1 April of the new year. An employee rated 1 or 2 is not eligible for a promotion in that cycle. Increments depend on the rating, the company budget and the employee's position in the salary band.

## Performance improvement plan
An employee who is rated 1, or rated 2 in consecutive cycles, may be placed on a performance improvement plan of 90 days. The plan sets clear goals and check-ins every two weeks, and its outcome is recorded by HR.
