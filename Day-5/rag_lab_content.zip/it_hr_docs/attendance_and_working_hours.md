# Attendance and Working Hours

## Standard working hours
The standard working day is 9 hours including a 1-hour break, Monday to Friday, which is 45 hours per week. Teams that run shifts follow the roster published by their manager.

## Core hours
All employees must be available between 10:00 and 16:00 (10 AM to 4 PM) on working days. Meetings with more than three participants should be scheduled inside core hours. Outside core hours, employees may arrange flexible start and finish times with their manager.

## Late arrival
Employees have a grace period of 15 minutes at start of day, which may be used up to 3 times per month. Each further late arrival in the same month is recorded as a half-day deduction from casual leave. Repeated late arrival is discussed with the manager and recorded in the performance file.

## Recording attendance
Attendance is recorded by swipe card at the office or by check-in on the HR portal on remote days. A missed punch or check-in must be regularised on the portal within 3 working days; otherwise the day is marked as absent.

## Overtime and compensatory off
Working on a weekly off or public holiday requires prior manager approval. Approved work earns a compensatory day off, which must be taken within 60 days. Compensatory offs are not paid out in cash and do not carry forward beyond 60 days.

## Public holidays
The Company observes 12 public holidays per year. The list for the next calendar year is published in December. For the number of days spent in the office each week, see the Remote Work Policy.
