# Password and Access Policy

## Password rules
Passwords must be at least 14 characters long. Passphrases made of several unrelated words are encouraged. A password must not reuse any of the last 10 passwords, and must not contain the employee's name, the Company name or a keyboard pattern.

## Multi-factor authentication
Multi-factor authentication (MFA) is mandatory for all accounts, including email, the VPN and cloud applications. An authenticator app is preferred over SMS codes. Employees who change phones must re-register their MFA device through the service desk before disposing of the old phone.

## Password rotation
Privileged and administrator accounts must change their passwords every 90 days. Standard user accounts are not forced to change passwords on a schedule, but must change them immediately if compromise is suspected.

## Account lockout
An account is locked after 5 failed sign-in attempts. It unlocks automatically after 30 minutes, or immediately when the employee verifies identity with the service desk.

## Access requests
New joiners receive baseline access (email, chat, HR portal, shared drives for their team) within 2 working days of joining. Any additional access needs written approval from the reporting manager and the system owner. Access to systems with customer or financial data is reviewed every quarter. When an employee leaves, all access is removed by the end of their last working day.

## Password managers
Employees should use the approved password manager to store work passwords. Passwords must never be written on paper, saved in browsers on shared devices, or sent by email or chat.
