# Expense Reimbursement Policy

## Scope
This policy covers business expenses incurred by employees on behalf of the Company, including travel, accommodation, meals while travelling, client entertainment and small purchases approved by the manager. It does not cover personal expenses.

## Submission deadline
Claims must be submitted through the Finance portal within 30 days of the expense date. Claims submitted after 30 days need the approval of the finance head and a written reason for the delay. Claims older than 90 days are rejected.

## Receipts
An original receipt or tax invoice is required for any expense above ₹500. For expenses of ₹500 or less, a self-declaration on the portal is enough. Photographs of receipts are accepted if they are clear and show the date, vendor and amount.

## Travel limits
Hotel stays are reimbursed up to ₹6,000 per night in metro cities and up to ₹4,000 per night in other cities. When travelling outstation, a daily meal allowance (per diem) of ₹1,500 is paid, and meals are not claimed separately. Air travel is economy class. Rail travel is 2AC. Local travel by cab is reimbursed on actuals with the ride receipt.

## Approval limits
The reporting manager approves claims up to ₹25,000. Claims above ₹25,000 need the additional approval of the finance head. Employees may not approve their own claims or those of their manager.

## Payment
Approved claims are paid into the employee's salary account within 10 working days of final approval. Rejected claims are returned with a reason, and can be resubmitted once with corrections.

## Expenses that are not reimbursed
Traffic fines, alcohol, personal entertainment, personal travel added to a business trip, and any expense without the required receipt are not reimbursed.
