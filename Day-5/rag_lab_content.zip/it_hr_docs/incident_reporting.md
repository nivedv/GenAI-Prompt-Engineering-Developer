# Incident Reporting Procedure

## What counts as an incident
An incident is any event that may harm the Company's information, systems or people. Examples are a lost or stolen device, clicking a suspected phishing link, suspected malware, sending data to the wrong recipient, or a suspected data leak.

## Lost or stolen devices
Report a lost or stolen laptop or phone within 1 hour of noticing it. Report to the security desk at security@company.example or through the ServiceDesk hotline, whichever is faster. IT will lock the device and, if needed, wipe it remotely. Do not wait to search for the device before reporting. If the device was stolen, also file a police report and give the reference number to Security.

## Severity levels
| Level | Description | First response |
| --- | --- | --- |
| P1 Critical | Data breach, ransomware, outage of a critical system | within 15 minutes |
| P2 High | Compromised account, malware on one device | within 2 hours |
| P3 Medium | Policy breach without data loss | next business day |
| P4 Low | Suspicious message, question about security | within 3 working days |

## Data breach notification
When a personal data breach is confirmed, the Legal team notifies the regulator and the affected individuals within 72 hours. Employees must not contact customers, regulators or the press about an incident themselves.

## Phishing
Do not click links or open attachments in suspicious messages. Forward the message to phishing@company.example and delete it. If you have already clicked the link or entered a password, report it at once as a P2 incident and change your password.

## After the incident
For P1 and P2 incidents, the incident owner holds a post-incident review within 5 working days and records the cause, the fix and the follow-up actions.
