# IT Acceptable Use Policy

## Company devices
Laptops, phones and accounts issued by the Company are for business use. Limited personal use is allowed if it does not affect work, security or the Company's reputation. Employees are responsible for the device issued to them and must not lend it to others, including family members.

## Software
Only software from the approved catalogue may be installed on company devices. Unlicensed or pirated software is prohibited. To obtain software that is not installed, follow the Software Request Process.

## Personal devices
Personal phones may be used for company email and chat only through the managed apps installed by IT. Company files must not be saved to personal laptops, personal cloud storage or personal email accounts.

## Removable media
USB storage ports on company laptops are blocked by default. An exception needs the approval of the manager and of IT Security, and is granted for 7 days at a time. Encrypted company-issued drives are exempt.

## Email and internet
Company email and internet use is monitored for security and compliance. Email is retained for 3 years. Employees must not use personal email or messaging apps for official communication with clients.

## Approved AI tools
Employees may use only the AI tools approved by IT. Confidential information, customer data and source code must never be pasted into public AI tools. Output from AI tools must be checked by the employee before it is used in business documents or decisions.

## Violations
Breaches of this policy are reported to IT Security and HR. Depending on seriousness, consequences range from a warning and loss of access to disciplinary action under the Code of Conduct.
