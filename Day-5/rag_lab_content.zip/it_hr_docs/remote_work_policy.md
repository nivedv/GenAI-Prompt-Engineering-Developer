# Remote Work Policy

## Hybrid model
Employees in roles that allow it follow a hybrid model: 3 days per week in the office and 2 days working remotely. Team leads set the in-office days for their team so that colleagues overlap. The in-office days are fixed per team, not chosen per person, and may be reviewed each quarter.

## Eligibility
Hybrid work is available to employees who have completed probation of 6 months. Roles that need physical presence, such as plant operations, laboratory work and facilities, are not eligible. During probation, employees work from the office five days a week unless the manager approves otherwise.

## Working from another city or abroad
Working remotely from a city other than the employee's base location needs manager approval. Working from another country needs approval from both the reporting manager and HR, requested at least 30 days in advance. Remote work abroad is limited to 20 working days per calendar year because of tax and legal exposure. Employees must not work from another country without written approval.

## Home office allowance
After confirmation, employees receive a one-time home office allowance of ₹15,000 for a desk, chair or monitor. Claims are made through the expense process with receipts. The allowance is not repeated unless equipment is lost or damaged and the manager approves.

## Connectivity and security
Employees must use the company laptop and connect through the company VPN whenever they access internal systems from outside the office. Public wifi may be used only with the VPN switched on. See the VPN and Remote Access guide for setup steps.

## Availability
On remote days employees must be reachable on the team chat during core hours and respond to messages within a reasonable time. Remote days are working days; leave must be applied for in the normal way.
