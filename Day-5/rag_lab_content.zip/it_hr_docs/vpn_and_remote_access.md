# VPN and Remote Access Guide

## When the VPN is required
The VPN is required whenever an employee accesses internal systems from outside the office, including from home, hotels and public wifi. Cloud applications that use single sign-on with MFA can be reached without the VPN, but internal file shares, the HR portal and the finance portal need it.

## Setting up the VPN client
1. Open Software Center on the company laptop and install the SecureLink client.
2. Start SecureLink and sign in with your company email address.
3. Approve the MFA prompt on your authenticator app.
4. Choose the Corporate profile and select Connect.

The client is installed only on company-managed laptops. Personal devices cannot connect to the VPN.

## Session rules
A VPN session times out after 8 hours and must be reconnected. The session is also disconnected after 30 minutes of inactivity. Split tunnelling is disabled, which means all traffic from the laptop goes through the Company network while connected. Do not use the VPN for streaming or personal downloads.

## Public wifi
Public wifi in cafes, airports and hotels may be used only with the VPN connected. If the VPN will not connect on a public network, switch to a mobile hotspot instead.

## Troubleshooting
If the client shows error 809, a firewall on the local network is blocking the connection; try a mobile hotspot. If the MFA prompt does not arrive, check that the phone has an internet connection and that the authenticator app time is correct. If problems continue, raise a ticket on the ServiceDesk portal with the error message and a screenshot.
