# New Joiner Onboarding Checklist

## Before the first day
HR sends the offer documents and the joining checklist at least 7 days before the joining date. IT prepares the laptop and accounts. The reporting manager nominates a buddy for the first 90 days.

## First day
New joiners report to the reception at 10:00 and receive an ID card, a laptop and a welcome kit. IT sets up the laptop and the first sign-in, including MFA. HR runs an orientation covering the Code of Conduct, leave, attendance and the benefits. The manager introduces the team and the buddy.

## First week
Baseline access to email, chat, the HR portal and team shared drives is available within 2 working days. By the end of the first week, the new joiner must complete the mandatory security awareness training and acknowledge the Code of Conduct and the IT Acceptable Use Policy on the HR portal. The manager agrees the 30-60-90 day goals.

## Probation
The probation period is 6 months. During probation, the notice period for resignation or termination is 30 days. A confirmation review is held in month 5, and the confirmation letter is issued on completion of probation if the review is satisfactory. Probation can be extended once, by up to 3 months, with written reasons.

## First 90 days
The buddy meets the new joiner weekly. The manager holds a check-in every two weeks. At 90 days, the new joiner and the manager review the goals and complete a short onboarding survey for HR.
