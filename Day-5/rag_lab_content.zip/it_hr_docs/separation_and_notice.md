# Separation and Notice Policy

## Resignation
An employee who wishes to resign must submit a written resignation by email to the reporting manager and HR. The resignation is effective from the date it is accepted by HR, which is normally within 2 working days.

## Notice period
The notice period for confirmed employees is 60 days. During probation, the notice period is 30 days. The Company may agree to a shorter notice period, with the employee paying salary for the shortfall (a notice buyout), if the manager and HR approve. Leave cannot be used to shorten the notice period unless the manager agrees in writing.

## Handover
During the notice period, the employee prepares a handover document, transfers work to the nominated colleague and updates the team on open items. On the last working day, the employee returns the laptop, ID card, access card and any other company property. All system access is removed by the end of the last working day.

## Final settlement
The full and final settlement is paid within 45 days of the last working day. It includes pending salary, encashment of earned leave as set out in the Leave Policy, reimbursement of approved expenses and any recoveries, such as unreturned property or an unserved notice period.

## Exit interview
HR holds an exit interview in the last week. Feedback is confidential and used only in aggregate to improve the workplace.

## Documents after exit
The experience letter and the relieving letter are issued within 7 working days of the last working day, once the handover and clearance are complete.
