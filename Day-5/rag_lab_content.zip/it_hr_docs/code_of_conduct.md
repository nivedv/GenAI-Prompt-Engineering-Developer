# Code of Conduct

## Our principles
Every employee is expected to act honestly, treat colleagues with respect, protect the Company's reputation and follow the law. This code applies in the office, on remote days, at client sites and at work-related events.

## Harassment and the Internal Committee
The Company has zero tolerance for harassment of any kind, including sexual harassment. The Internal Committee (IC) handles complaints under the law on prevention of sexual harassment at the workplace. A complaint should be made in writing to the IC at ic@company.example within 3 months of the incident; the IC may extend this period for good reason. The IC completes its inquiry within 90 days. The complainant's identity is kept confidential, and retaliation against a complainant or witness is a disciplinary offence.

## Conflicts of interest
Employees must declare to HR any outside business interest, directorship or employment of a close relative with a competitor, supplier or client. Gifts received from clients or suppliers worth more than ₹2,000 must be declared to HR and may be returned or donated. Cash gifts must always be declined.

## Confidentiality
Employees must not disclose confidential information about the Company, customers or colleagues during or after employment. This includes pasting confidential material into external tools.

## Raising concerns
Employees can report suspected fraud, bribery or misconduct to their manager, to HR or through the ethics hotline, which is available 24 hours a day and accepts anonymous reports. Good-faith reports are protected from retaliation.

## Disciplinary action
Breaches of this code may lead to a written warning, suspension, termination of employment or, where the law requires, a report to the authorities. The action taken depends on the seriousness of the breach and is decided after the employee has been heard.
